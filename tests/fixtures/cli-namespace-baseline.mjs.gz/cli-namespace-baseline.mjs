#!/usr/bin/env node
// waypost — Waypost: harness-agnostic project store & verified loop.
// One entry point for Claude Code, Codex and OpenCode. The dispatcher owns
// every write to disk; the scripts under scripts/ stay pure compute printing
// JSON, which is what lets doctor re-run them to detect drift.
//
// Subcommands: see help() at the bottom, or `waypost help`.

import { resolve, dirname, join, sep, basename, relative } from "node:path";
import { fileURLToPath, pathToFileURL } from "node:url";
import {
  existsSync, mkdirSync, writeFileSync, readFileSync, readdirSync, statSync, lstatSync, unlinkSync, rmSync,
  statfsSync, appendFileSync, realpathSync, renameSync, openSync, closeSync, fsyncSync, linkSync,
} from "node:fs";
import { spawnSync, spawn } from "node:child_process";
import { createHash, randomUUID } from "node:crypto";
import { acquireLock, releaseLock } from "../scripts/machine-lock.mjs";
import { homedir, hostname, setPriority, uptime as osUptime, constants as osConstants } from "node:os";
import {
  parseFrontmatter, isInsideVault, writeFileAtomic, sessionId, sessionIdFlag, storyRefOf, expandHome,
  storedVaultPath, resolveVaultPath, bindingInfo, selfInstallOff, readVaultConfig, writeVaultConfig, readConfig as readConfigLib, isLinkedWorktree, worktreeTag,
  machineStateDir, legacyStateDirs, legacyDirsToMove, ensureMachineStateDir, accountStateDir, LIMIT_WRITER, stateWriteHint, askYesNo, readCleanupSetting, readLastAutoCleanup, REMOVING_DIR,
} from "../scripts/lib.mjs";

// Captured before main() (below) pins WAYPOST_SESSION_ID, WAYPOST_HARNESS and
// WAYPOST_PROC (the harness process) onto process.env for THIS process's own
// labelling (heartbeat, commit trailers): `run --heavy`'s spawned COMMAND must
// not silently inherit an identity this process only invented for itself —
// see runHeavy()'s use of these.
const INHERITED_SESSION_ID = process.env.WAYPOST_SESSION_ID;
const INHERITED_HARNESS = process.env.WAYPOST_HARNESS;
const INHERITED_PROC = process.env.WAYPOST_PROC;

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const SCRIPT = (name) => join(ROOT, "scripts", `${name}.mjs`);
// A file URL, not `file://${path}`: on Windows that string is only valid by
// luck for a drive letter and is rejected outright for a UNC checkout
// (\\Mac\share\…), which is how an npm shim on a Parallels share launches us.
const SCRIPT_URL = (name) => pathToFileURL(SCRIPT(name)).href;
const VERSION = (() => {
  try { return JSON.parse(readFileSync(join(ROOT, "package.json"), "utf8")).version; }
  catch { return "0.0.0"; }
})();

function fail(msg) {
  process.stderr.write(`waypost: ${msg}\n`);
  process.exit(1);
}

// Run a core script. `capture` pipes stdout so the dispatcher can act on the
// JSON; otherwise the child owns the terminal. Either way the child's exit
// code is ours — a harness scripting `waypost doctor && ...` must see failures.
//
// The tool root is the tree this executable belongs to, always: the children
// get WAYPOST_HOME=ROOT even when the caller exported something else. A
// dispatcher validating layouts against its own tree while its scripts read
// templates from another (O-4) is two versions of the tool in one command
// line. WAYPOST_HOME still means "tool root" for a script run directly.
function run(script, args = [], { capture = false } = {}) {
  const r = spawnSync(process.execPath, [SCRIPT(script), ...args], {
    encoding: "utf8",
    stdio: capture ? ["inherit", "pipe", "inherit"] : "inherit",
    env: { ...process.env, WAYPOST_HOME: ROOT },
  });
  if (r.error) fail(`${script}: ${r.error.message}`);
  if (r.status !== 0) process.exit(r.status ?? 1);
  return capture ? r.stdout : "";
}

function runJson(script, args = []) {
  const out = run(script, args, { capture: true });
  try {
    return JSON.parse(out);
  } catch {
    process.stdout.write(out);
    fail(`${script}: expected JSON on stdout`);
  }
}

// Create-only project installation. Never merge user settings or read credentials.
function installMcpConfig(argv) {
  const writes = argv.filter(value => value === "--write").length;
  if (!writes) { run("team-mcp-config", argv); return; }
  if (writes !== 1) fail("MCP config: duplicate --write");
  if (argv.indexOf("--write") % 2 !== 0) fail("MCP config: --write cannot replace an option value");
  const args = argv.filter(value => value !== "--write");
  const preview = runJson("team-mcp-config", args);
  let temporary, fd, ownTemporary = false, published = false, cleanupFailed = false;
  try {
    const project = preview.execution.args[2];
    const rootInfo = lstatSync(project);
    if (!rootInfo.isDirectory() || rootInfo.isSymbolicLink()) throw new Error("project-directory-required");
    const root = realpathSync(project);
    const offset = relative(project, preview.target.file);
    const parts = offset.split(sep);
    if (!offset || parts.some(p => !p || p === "." || p === ".." || /[<>:"|?*]/.test(p) || /[. ]$/.test(p) ||
        /^(con|prn|aux|nul|com[1-9]|lpt[1-9])(?:\.|$)/i.test(p) || [".git", ".waypost"].includes(p.toLowerCase())) ||
        (preview.harness !== "claude" && parts.some(p => p.toLowerCase() === ".claude"))) throw new Error("unsafe-project-target");
    let parent = root;
    for (const part of parts.slice(0, -1)) {
      const next = join(parent, part);
      try { mkdirSync(next, { mode: 0o700 }); } catch (error) { if (error.code !== "EEXIST") throw error; }
      const info = lstatSync(next);
      if (info.isSymbolicLink() || !info.isDirectory()) throw new Error("unsafe-project-parent");
      parent = realpathSync(next);
      const inside = relative(root, parent);
      if (inside === ".." || inside.startsWith(".." + sep) || resolve(root, inside) !== parent) throw new Error("unsafe-project-parent");
    }
    const target = join(parent, parts.at(-1));
    // lstat also detects dangling links; linkSync is the final no-overwrite gate.
    try { lstatSync(target); throw new Error("config-already-exists-use-preview-to-merge"); }
    catch (error) { if (error.code !== "ENOENT") throw error; }
    temporary = join(parent, ".waypost-mcp-config-" + randomUUID() + ".tmp");
    fd = openSync(temporary, "wx", 0o600); ownTemporary = true;
    writeFileSync(fd, preview.snippet, "utf8");
    fsyncSync(fd); closeSync(fd); fd = undefined;
    linkSync(temporary, target); published = true;
  } catch (error) {
    // No paths, credential contents or arbitrary filesystem diagnostics.
    const code = error.code === "EEXIST" ? "config-already-exists-use-preview-to-merge" :
      ["project-directory-required", "unsafe-project-target", "unsafe-project-parent", "config-already-exists-use-preview-to-merge"].includes(error.message) ? error.message : "config-installation-failed";
    process.stderr.write("waypost MCP config: " + code + "\n"); process.exitCode = 1;
  } finally {
    if (fd !== undefined) { try { closeSync(fd); } catch {} }
    if (ownTemporary) { try { unlinkSync(temporary); } catch (error) { if (error.code !== "ENOENT") cleanupFailed = true; } }
  }
  if (published) {
    const result = { ...preview, preview_only: false, written: true, cleanup_pending: cleanupFailed,
      limitations: preview.limitations.filter(value => !value.includes("Nothing was written.")) };
    result.limitations.push("Only a new project config was created; credentials and existing settings were not read. No approvals or native capabilities changed.",
      "Hard-link publication requires filesystem support. POSIX modes do not verify Windows ACLs. Parent checks are best-effort on a trusted filesystem, not protection against hostile concurrent ancestor replacement.");
    process.stdout.write(JSON.stringify(result, null, 2) + "\n");
    if (cleanupFailed) process.stderr.write("waypost MCP config: installed; private temporary cleanup pending\n");
  } else if (cleanupFailed) process.stderr.write("waypost MCP config: installation failed; private temporary cleanup pending\n");
}

function projectRoot() {
  return process.env.WAYPOST_PROJECT_DIR || process.env.CLAUDE_PROJECT_DIR || process.cwd();
}

// The binding, wherever it comes from: this project's own .waypost/, or, in a
// linked worktree without one, the main worktree's (ADR-0010).
function configPath() {
  return bindingInfo().path;
}

// null means "not bound" — the right next step is `waypost bind`/`waypost setup`. A
// config that exists but does not parse is a different, louder problem: left
// indistinguishable from "not bound", `waypost setup` would silently rebind over
// it and discard whatever settings the file still held.
function readConfig() {
  try { return readConfigLib(); }
  catch (e) { fail(`config exists but is unreadable: ${configPath()}: ${e.message}`); }
}

// Options that take a value. Everything else starting with `--` is a boolean,
// which is what separates `draft --write adr "T"` (three tokens, one flag) from
// `draft --lang ru adr "T"` (four tokens, one flag with a value). Guessing
// "the token after any flag is its value" ate the first positional whenever a
// boolean flag was written before it.
const VALUED = new Set(["--harness", "--layout", "--lang", "--only", "--id",
  "--budget", "--project", "--since", "--for", "--kind", "--limit", "--message",
  "--story", "--merge", "--session", "--provider", "--os", "--older-than", "--wait", "--release", "--reason", "--self-install"]);

// The literal `--` stops flag parsing, same as most POSIX CLIs: everything
// after it is positional even if it is spelled like a flag (`waypost search --
// --literal`). Only tokens before it are eligible to be a flag name or a
// flag's value.
function splitAtTerminator(args) {
  const i = args.indexOf("--");
  return i === -1 ? { head: args, tail: [] } : { head: args.slice(0, i), tail: args.slice(i + 1) };
}

function flag(args, name) {
  const { head } = splitAtTerminator(args);
  return head.includes(name) || head.some((a) => a === `${name}=true`);
}

function opt(args, name, dflt = null) {
  const { head } = splitAtTerminator(args);
  const i = head.indexOf(name);
  if (i !== -1) {
    const v = head[i + 1];
    if (v === undefined) fail(`${name} requires a value`);
    return v;
  }
  const eq = head.find((a) => a.startsWith(`${name}=`));
  return eq ? eq.slice(name.length + 1) : dflt;
}

function positionals(args) {
  const { head, tail } = splitAtTerminator(args);
  const out = [];
  for (let i = 0; i < head.length; i++) {
    const a = head[i];
    if (a.startsWith("--")) { if (VALUED.has(a)) i++; continue; }
    out.push(a);
  }
  out.push(...tail);
  return out;
}

// ─── setup: one command that leaves the project ready ──────────────────
//
// Reading a manual to configure a tool is time the tool was supposed to save.
// Everything here is derivable: where the vault goes, which harnesses this
// project uses, which repairs are mechanical. So derive it, do it, and print
// what happened — with --dry-run for anyone who wants to look first.
async function handleSetup(args) {
  const dry = flag(args, "--dry-run");
  const say = (l) => process.stdout.write(l + "\n");
  const step = (label, fn) => { if (dry) { say(`would ${label}`); return null; } say(label); return fn(); };

  const existing = readConfig();
  const vault = opt(args, "--vault") || (existing && existing.vault_path) || guessVault();
  say(`project ${projectRoot()}`);

  if (!existing || !existing.vault_path) {
    step(`bind vault ${vault}`, () => handleBind([vault, ...passThrough(args, ["--layout", "--lang"])]));
  } else {
    say(`vault  ${existing.vault_path} (already bound)`);
    step("scaffold any missing layout folders", () => handleScaffold([]));
  }

  // The harness running this command is the one project setup is being run
  // inside, so it is evidence like any other — the same union doctor already
  // makes (scripts/doctor.mjs) and the same reason selfInstall reads
  // detectHarness(). Without it, setup was the one consumer that asked the
  // filesystem alone, and a real project could look empty to it: measured
  // 2026-09-30, from inside a live `codex` session (codex-cli 0.159.2) in a
  // repo with a README and no marker of any kind, `setup --dry-run` answered
  // "no harness detected" while detectHarness() in the same directory
  // answered "codex". Codex exports CODEX_SANDBOX and
  // CODEX_SANDBOX_NETWORK_DISABLED (both declared in harnesses/codex.json) and
  // never creates a project-local .codex/ of its own, so file markers alone
  // cannot see it. `AGENTS.md` had been hiding that: a real Codex project
  // almost always has one, and the marker made the wrong code path give the
  // right answer.
  //
  // This makes no precedence claim between the two sources — they are unioned.
  // A file marker says the project uses that harness; the running process says
  // someone is in it right now, and both can be true.
  //
  // --harness is read first and short-circuits the detection below entirely: an
  // explicit choice is a decision, and a decision must not depend on whether the
  // two sources happened to be readable — or on an ambient process table naming
  // somebody else's harness.
  const harnesses = opt(args, "--harness");
  const detected = harnesses ? [] : [...new Set([
    ...await detectedHarnesses(),
    ...await runningHarness().then((h) => (h ? [h] : [])),
  ])];
  if (harnesses || detected.length) {
    // The list is passed explicitly, not left to the child: `agents install`
    // re-detects from markers on its own, so a harness found only by the
    // running process would be named in the label and then skipped.
    const list = harnesses || detected.join(",");
    const named = list.split(",").join(", ");      // --harness takes a,b; a human reads a, b
    step(`install roles for ${named}`, () => run("agents", ["install", "--harness", list]));
    step(`install skills for ${named}`, () => run("skills", ["install", "--harness", list]));
    step("register the routing block", () => run("agents", ["register"]));
  } else {
    say("no harness detected — run `waypost agents install --harness <id>` once you pick one");
    say("  (`waypost harnesses --all` lists what is supported)");
  }

  // WP-17, the discovery story: the machine and project profiles, under the
  // same refresh rule `waypost profile` uses (missing, older than 30 days, or
  // --refresh — never forced just because setup is running). Discovery is a
  // PATH stat plus a handful of ≤3s subprocess calls, not heavy work in the
  // WP-18 sense, so it takes no machine-wide slot; the machine audit that
  // does is a later story's step, not this one.
  //
  // --dry-run reports what refreshing WOULD do (read-only: load the existing
  // profiles, if any, and say whether each is due) rather than the generic
  // `step()` one-liner every other step uses — "would discover" alone never
  // says whether a fresh profile would be kept or a stale one rebuilt.
  // Set inside the discovery step below when it actually refreshes the
  // machine profile THIS run — the audit step (last, below) reads it to
  // decide whether the machine is its to audit at all this time.
  let machineRefreshedThisRun = false;

  if (dry) {
    say("would discover tools and ecosystems");
    const discovery = await import(SCRIPT_URL("discovery"));
    const presence = await import(SCRIPT_URL("presence"));
    const home = homedir();
    const host = presence.hostSlug();
    const machinePath = discovery.machineProfilePath({ home, host });
    const load = (p) => {
      if (!existsSync(p)) return null;
      try { return JSON.parse(readFileSync(p, "utf8")); } catch { return null; }
    };
    const describe = (label, prof) => discovery.needsRefresh(prof, {})
      ? `  would refresh the ${label} profile`
      : `  would keep the ${label} profile (generated ${prof.generated_at})`;
    say(describe("machine", load(machinePath)));
    // Item 6: a project profile at $HOME would write into the user's home
    // directory itself — the same reasoning `waypost size --project`
    // already refuses ($HOME as a project root, scripts/sizes.mjs).
    if (resolve(projectRoot()) === resolve(home)) {
      say("  no project here — machine profile only");
    } else {
      const projectPath = discovery.projectProfilePath({ projectRoot: projectRoot(), host });
      say(describe("project", load(projectPath)));
    }
  } else {
    await step("discover tools and ecosystems", async () => {
      // A discovery failure (an unwritable machine-state directory, a
      // registry that fails to load, …) must not take the rest of setup
      // down with it — the vault is already bound, roles already installed,
      // and the repair step below still matters. Reported inline instead.
      try {
        const r = await refreshProfiles({ force: false });
        machineRefreshedThisRun = Boolean(r.machineRefreshed);
        say(`  machine  ${r.machineRefreshed ? "refreshed" : "kept"} — ${r.machine.tools.length} tool(s), ${r.machine.caches.length} cache path(s)`);
        if (r.noProject) say("  project  no project here — machine profile only");
        else say(`  project  ${r.projectRefreshed ? "refreshed" : "kept"} — ${r.project.ecosystems.length} ecosystem(s)`);
      } catch (e) {
        say(`  discovery failed: ${e.message} — waypost profile to retry`);
      }
    });
  }

  // Not run(): doctor is a diagnostic, and `--fix` only mends what is
  // mechanical — a harness/spec/layout finding it cannot touch must not turn
  // `waypost setup` into a hard failure for having done the mechanical part of
  // its job. spawnSync here so setup can read and print the report itself
  // and add the one line that matters: whether anything still needs a human.
  step("repair the mechanical install findings", () => {
    const r = spawnSync(process.execPath, [SCRIPT("doctor"), "--install", "--fix"], {
      encoding: "utf8", env: { ...process.env, WAYPOST_HOME: ROOT },
    });
    process.stdout.write(r.stdout || "");
    if (r.stderr) process.stderr.write(r.stderr);
    const m = (r.stdout || "").match(/Summary: (\d+) issue/);
    if (m && Number(m[1]) > 0) process.stdout.write(`${m[1]} finding(s) remain — waypost doctor\n`);
  });

  // WP-17, the clean stories (ADR "Disk hygiene by discovery" Decision 6):
  // the audit as setup's own last step, after repair, before the footer.
  // Never takes setup down with it — a slot refusal or any other failure is
  // reported and setup still exits 0; setup itself removes nothing without
  // the same yes `waypost clean --apply` needs, asked at most once here.
  await step("audit build output (project, and the machine if its profile was just refreshed)", async () => {
    try {
      const capacity = await import(SCRIPT_URL("capacity"));
      const presence = await import(SCRIPT_URL("presence"));
      const dir = slotsDir(presence);
      mkdirSync(dir, { recursive: true });
      const where = slotWhere(projectRoot());
      const claim = await claimSlot(dir, ["waypost", "setup", "--audit"], capacity, presence, where);
      if (!claim.ok) {
        say(`  audit skipped: ${claim.reason} — waypost clean`);
        return;
      }
      recordAuthority(claim.file, capacity);
      try {
        const cleanup = await import(SCRIPT_URL("cleanup"));
        const sizes = await import(SCRIPT_URL("sizes"));
        const toolchains = await import(SCRIPT_URL("toolchains"));
        const discovery = await import(SCRIPT_URL("discovery"));
        const mods = { cleanup, sizes, toolchains, presence, discovery };
        const auditNow = cleanNow();
        const ctx = gatherCleanContext(mods, { budget: sizes.DEFAULT_ENTRY_BUDGET, includeMachine: machineRefreshedThisRun });
        const classified = planFromContext(ctx, cleanup, auditNow);
        printAuditSummary(classified, say, ctx.inUseSignal);

        const shouldItems = classified.filter((it) => it.class === "should");
        const isTTY = Boolean(process.stdin.isTTY);
        const harnessDetected = await isHarnessDetected();
        if (shouldItems.length && isTTY && !harnessDetected) {
          const consent = cleanup.consent({ yes: false, reason: null, isTTY, harnessDetected });
          const result = await applyClean({ mode: "should" }, consent, mods, auditNow, { source: "setup", prebuilt: { ctx, classified } });
          if (result.declined) {
            say("  not confirmed — nothing removed");
          } else {
            const removedCount = result.items.filter((i) => i.result === "removed" || i.result === "partial").length;
            say(`  removed ${removedCount} item(s) — waypost clean for the rest`);
          }
        } else if (shouldItems.length) {
          say("  review and remove: waypost clean");
        }
      } finally {
        claim.release();
      }
    } catch (e) {
      say(`  audit failed: ${e.message} — waypost clean to retry`);
    }
  });

  if (!dry) {
    process.stdout.write("\nready. Next:\n");
    process.stdout.write("  waypost next                      what this project needs right now\n");
    process.stdout.write("  waypost brief                     orientation at the start of a session\n");
    process.stdout.write('  waypost draft adr "<decision>" --write\n');
  }
}

// A vault the project already has, or a conventional place for a new one. Never
// a path outside the project: the vault travels with the repository unless the
// user says otherwise.
function guessVault() {
  const root = projectRoot();
  for (const c of ["vault", "docs/vault", "knowledge", ".vault"]) {
    if (existsSync(join(root, c, "adr")) || existsSync(join(root, c, "epics"))) return join(root, c);
  }
  return join(root, existsSync(join(root, "docs")) ? "docs/vault" : "vault");
}

// Both functions below import scripts/agents.mjs in-process, which is the
// right default and the reason there is one detection instead of two. It
// costs the thing `run()` gets for free: the child it spawns is given
// WAYPOST_HOME=ROOT, so pluginRoot() resolves the registry from this
// executable's own tree whatever the caller's environment says. An in-process
// import has no such pin, and pluginRoot() honours WAYPOST_HOME — a documented
// user setting — and CLAUDE_PLUGIN_ROOT, which is itself one of the `env`
// markers the `claude` registry entry declares. Left unpinned, a foreign root
// supplies the ids themselves: a project with real markers is named after
// whatever that root declares, or after nothing at all. Hence withRegistryHome()
// around every registry read — including main()'s own, which is the first and
// used to prime the memo every later read inherited — and a diagnostic instead
// of silence: "no harness detected" with no reason is the one answer that cannot
// be acted on. `scripts/agents.mjs` keys that memo on the root as well: the pin
// is what makes this answer right, the key is what stops a second caller from
// inheriting the first one's.
function withRegistryHome(fn) {
  const saved = process.env.WAYPOST_HOME;
  process.env.WAYPOST_HOME = ROOT;
  try { return fn(); }
  finally {
    if (saved === undefined) delete process.env.WAYPOST_HOME;
    else process.env.WAYPOST_HOME = saved;
  }
}

function registryReadFailed(what, e) {
  process.stderr.write(`waypost setup: cannot read the harness registry for ${what}: ${e.message}\n`);
  process.stderr.write("waypost setup: WAYPOST_HOME / CLAUDE_PLUGIN_ROOT may point elsewhere; unset it to use this waypost's own registry.\n");
}

// The harnesses this project shows evidence of, by the same detector
// `agents install` uses: a marker counts only when the user's own content
// remains in it. Reading the `agents harnesses --json` projection and testing
// each `detect` path with a bare existsSync — which is what this did — is
// weaker than the detector it stood in for. Measured on the E-1 fixture
// (`.pi/` + README + an `AGENTS.md` carrying only waypost's routing block),
// one command printing both sets, with the run pinned to `pi` so nothing
// ambient is added: before setup, the projection reads `[ 'codex', 'pi' ]`
// where the module reads `[ 'pi' ]`; after setup, `[ 'antigravity', 'codex',
// 'pi' ]` where the module still reads `[ 'pi' ]`. The extra ids are exactly
// the unrequested directories that would be created. Since setup hands the
// result to the child as an explicit `--harness` list, the difference stops
// being a label and becomes what gets written.
async function detectedHarnesses() {
  try {
    const A = await import(SCRIPT_URL("agents"));
    return withRegistryHome(() => A.detectHarnesses(projectRoot()));
  } catch (e) {
    registryReadFailed("the project's harnesses", e);
    return [];
  }
}

// The harness this command is running inside, or null when it cannot be
// determined. main() has already resolved it into WAYPOST_HARNESS for every
// non-quiet command (one `ps` per working command, shared with presence and
// commit), so the first line is the answer and detectHarness() is only the
// fallback for a quiet command or a detection that threw. It is deliberately a
// question about *now* and never about the project, which is what
// detectedHarnesses() answers; callers union the two.
async function runningHarness() {
  try {
    const A = await import(SCRIPT_URL("agents"));
    return withRegistryHome(() => {
      const h = process.env.WAYPOST_HARNESS || A.detectHarness();
      return h && h !== "unknown" && A.harnessIds().includes(h) ? h : null;
    });
  } catch (e) {
    registryReadFailed("the running harness", e);
    return null;
  }
}

function passThrough(args, names) {
  const out = [];
  for (const n of names) { const v = opt(args, n); if (v) out.push(n, v); }
  return out;
}

// A finding's message, trimmed to its lead clause for a one-line summary:
// split on " — " first (several finding generators use it deliberately as a
// clause separator), else on the first SENTENCE-ending period (one followed
// by whitespace or end of string) — never the first bare ".", which cuts a
// message off mid-path on anything naming a file (kanban.md, .gitattributes,
// .waypost/…) or a domain-shaped word.
function leadClause(message) {
  const dash = message.split(" — ")[0];
  return dash !== message ? dash : message.split(/\.(?:\s|$)/)[0];
}

// ─── next: what this project needs right now ───────────────────────────
//
// The judgement an agent otherwise has to make from scratch every session, made
// deterministically instead: read the state, rank what is actionable, print the
// command. Cheap by construction — no artifact content, one line per item.
function handleNext(args) {
  const cfg = readConfig();
  const items = [];
  if (!cfg || !cfg.vault_path) {
    process.stdout.write("not bound to a vault yet — run `waypost setup`\n");
    return;
  }
  const findings = (() => {
    try { return JSON.parse(run("doctor", ["--json"], { capture: true })); } catch { return []; }
  })();
  const by = (check, level) => findings.filter((f) => f.check === check && (!level || f.level === level));

  for (const f of findings.filter((f) => f.level === "issue")) {
    items.push([1, leadClause(f.message).slice(0, 110), repairFor(f)]);
  }
  const state = (() => {
    try { return JSON.parse(run("sessions", ["--json"], { capture: true })); } catch { return {}; }
  })();
  for (const c of (state.claims || []).filter((c) => c.session !== state.session_id)) {
    items.push([2, `${c.story} is being worked on by ${c.session} (${c.harness || "?"}, ${c.host})`,
      "coordinate before touching it"]);
  }
  // Ready work outranks warnings: an unblocked, unclaimed story is what a
  // session came for (WP-15). Three at most; `waypost ready` has the rest.
  const ready = (() => {
    try { return JSON.parse(run("ready", ["--json"], { capture: true })).ready || []; } catch { return []; }
  })();
  for (const s of ready.slice(0, 3)) {
    items.push([2, `ready: ${s.title} (${s.epic}, ${s.priority})`, `waypost story plan ${s.rel} --write`]);
  }
  for (const f of by("work-without-story", "warn")) {
    items.push([3, "source changes with no story open", 'waypost draft story <EPIC> "<title>" --write']);
  }
  for (const f of findings.filter((f) => f.level === "warn" && f.check !== "work-without-story")) {
    items.push([4, leadClause(f.message).slice(0, 110), repairFor(f)]);
  }
  for (const f of by("agent-roles", "info").concat(by("agents-block", "info"))) {
    items.push([5, leadClause(f.message).slice(0, 110), repairFor(f)]);
  }

  if (!items.length) {
    process.stdout.write(`nothing needs doing: vault consistent, ${selfInstallOff(cfg.vault_path) ? "" : "roles installed, "}no conflicting session.\n`
      + "Next feature-sized change starts with `waypost draft story <EPIC> \"<title>\" --write`.\n");
    return;
  }
  items.sort((a, b) => a[0] - b[0]);
  for (const [, what, how] of items.slice(0, 8)) {
    process.stdout.write(`- ${what}\n${how ? `    ${how}\n` : ""}`);
  }
  if (items.length > 8) process.stdout.write(`…and ${items.length - 8} more (waypost doctor)\n`);
}

function repairFor(f) {
  if (f.check === "code-refs") return "fix the path, or mark it (waiting)/(planned)/(deleted)";
  if (f.check === "supersedes") return "correct supersedes/superseded_by on both artifacts";
  if (f.check === "acceptance-gate") return "record the review outcome in review_status";
  const map = {
    kanban: "waypost reconcile --write", "code-map": "waypost reconcile --write", indexes: "waypost reconcile --write",
    graph: "waypost graph", "agent-roles": "waypost agents install", "agents-block": "waypost agents register",
    gitignore: "waypost doctor --fix", "vault-git": "waypost doctor --fix", "merge-driver": "waypost doctor --fix",
    "line-endings": "waypost doctor --fix", config: "waypost setup",
    "claude-bridge": "waypost doctor --fix", "claude-import-missing": "waypost doctor --fix", "instructions-size": "waypost doctor",
    "story-deps": "waypost ready --all", "adr-number": "waypost doctor", "adr-guard": "waypost doctor",
    "agent-skills": "waypost skills install", launcher: "waypost launcher --write",
  };
  return map[f.check] || null;
}

// ─── bind ──────────────────────────────────────────────────────────────

// A-2: shared by handleBind (a --layout flag) and handleScaffold (a layout
// already sitting in .waypost/projectstore.json) — a bad value in either place
// must get this same actionable message, not a raw ENOENT from whichever
// readFileSync happens to hit it first.
function checkLayoutExists(layout) {
  if (!existsSync(join(ROOT, "scaffold", "layouts", `${layout}.json`))) {
    fail(`unknown layout "${layout}" — available: ${readdirSync(join(ROOT, "scaffold", "layouts")).map((n) => n.replace(/\.json$/, "")).join(", ")}`);
  }
}

function handleBind(args) {
  const [vault] = positionals(args);
  if (!vault) fail('bind <vault-path> [--layout engineering] [--lang en|ru|es|de|fr|zh] [--self-install off|on]');
  const selfInstall = opt(args, "--self-install");
  if (selfInstall !== null && !["off", "on"].includes(selfInstall)) fail("--self-install takes off or on");
  // An unreadable policy file would read as {} and be overwritten with one key,
  // dropping spec_policy and the gates; refuse before anything is written.
  const policyPath = join(resolve(expandHome(vault)), ".projectstore.json");
  if (selfInstall !== null && existsSync(policyPath)) {
    let v; try { v = JSON.parse(readFileSync(policyPath, "utf8")); } catch { v = null; }
    if (!v || typeof v !== "object" || Array.isArray(v)) fail(`${policyPath} is not a JSON object — fix it before --self-install changes it`);
  }
  const abs = resolve(expandHome(vault));
  // A re-bind keeps what the project already chose: `waypost bind <same vault>`
  // used to reset language and layout to their defaults unless both flags were
  // repeated, which is how a Russian vault came back English.
  const existing = readConfig();
  const layout = opt(args, "--layout", (existing && existing.layout) || "engineering");
  const lang = opt(args, "--lang", (existing && existing.language) || "en");
  checkLayoutExists(layout);
  if (!existsSync(join(ROOT, "templates", lang))) {
    fail(`unknown language "${lang}" — available: ${readdirSync(join(ROOT, "templates")).filter((n) => !n.includes(".")).join(", ")}`);
  }
  if (existing && existing.vault_path && resolve(existing.vault_path) !== abs && !flag(args, "--force")) {
    fail(`already bound to ${existing.vault_path} — re-run with --force to rebind to ${abs}`);
  }
  mkdirSync(abs, { recursive: true });
  const cfgPath = join(projectRoot(), ".waypost", "projectstore.json");
  mkdirSync(dirname(cfgPath), { recursive: true });
  const stored = storedVaultPath(abs);
  const cfg = {
    ...(existing || {}),
    vault_path: stored,
    layout,
    language: lang,
    default_author: (existing && existing.default_author) || gitUser(),
    waypost: { version: VERSION },
  };
  writeFileSync(cfgPath, JSON.stringify(cfg, null, 2) + "\n", "utf8");
  process.stdout.write(`bound  ${abs}${stored !== abs ? `  (stored as ${stored}, relative to the project)` : ""}\nconfig ${cfgPath}\n`);
  process.env.WAYPOST_PROJECT_DIR = projectRoot();
  handleScaffold([]);
  // The opt-out lives in the committed vault policy, so every clone sees it;
  // merged, never replacing the other policy keys.
  if (selfInstall !== null && (selfInstall === "off" || existsSync(policyPath))) {
    const { self_install: _drop, ...rest } = readVaultConfig(abs);
    writeVaultConfig(abs, selfInstall === "off" ? { ...rest, self_install: "off" } : rest);
    process.stdout.write(`self_install ${selfInstall} in ${join(abs, ".projectstore.json")} — commit it\n`);
  }
  process.stdout.write(
    "\nnext:\n" +
    (selfInstallOff(abs) ? "" : "  waypost agents install         install the roles into the harnesses this project uses\n") +
    '  waypost draft adr "<title>" --write\n' +
    "  waypost doctor\n",
  );
}

function gitUser() {
  const r = spawnSync("git", ["config", "--get", "user.name"], { encoding: "utf8" });
  return (r.stdout || "").trim() || process.env.USER || "unknown";
}

// ─── scaffold ──────────────────────────────────────────────────────────

// The deterministic half of upstream's /bind: layout folders and their index
// READMEs. Prose lives in prompts/bind.md; the directories are mechanical, so
// they are the CLI's job and never an LLM's.
function handleScaffold(args) {
  const cfg = readConfig();
  if (!cfg || !cfg.vault_path) fail("no bound vault — run `waypost bind <vault-path>` first");
  checkLayoutExists(cfg.layout || "engineering");
  const layout = JSON.parse(readFileSync(join(ROOT, "scaffold", "layouts", `${cfg.layout || "engineering"}.json`), "utf8"));
  const lang = cfg.language || "en";
  const created = [];
  for (const folder of layout.folders) {
    const dir = join(cfg.vault_path, folder.path);
    if (!existsSync(dir)) { mkdirSync(dir, { recursive: true }); created.push(folder.path + "/"); }
    if (!folder.readme) continue;
    const p = join(dir, "README.md");
    if (existsSync(p)) continue;
    const tmpl = readFileSync(join(ROOT, "templates", lang, "folder-readme.md.tmpl"), "utf8");
    const title = folder.path.charAt(0).toUpperCase() + folder.path.slice(1);
    // doctor reads the first prose paragraph as the folder's purpose, so the
    // default has to say what the folder holds, not merely name it.
    writeFileSync(p, tmpl
      .replace(/\{\{folder_name\}\}/g, title)
      .replace(/\{\{folder_description\}\}/g,
        `\`${folder.kind}\` artifacts of the \`${layout.name}\` layout, maintained by waypost.`), "utf8");
    created.push(`${folder.path}/README.md`);
  }
  if (flag(args, "--json")) { process.stdout.write(JSON.stringify({ created }, null, 2) + "\n"); return; }
  if (!created.length) process.stdout.write("scaffold: vault already complete\n");
  else process.stdout.write(`scaffold: created ${created.length} item(s)\n  ${created.join("\n  ")}\n`);
}

// ─── draft ─────────────────────────────────────────────────────────────

function handleDraft(args) {
  const pos = positionals(args);
  const [kind, ...rest] = pos;
  if (!kind || !rest.length) {
    fail('draft <adr|spec|epic|story|research|concept|meeting|runbook> "<title>" [--write] [--lang <code>]\n' +
         '       draft epic <EPIC-ID> "<title>"   |   draft story <EPIC-ID> "<title>"');
  }
  const lang = opt(args, "--lang");
  const out = runJson("draft", [kind, ...rest, ...(lang ? ["--lang", lang] : [])]);
  if (!flag(args, "--write")) {
    if (flag(args, "--json")) { process.stdout.write(JSON.stringify(out, null, 2) + "\n"); return; }
    // A preview used to print the whole rendered artifact — several hundred
    // tokens of template the reader is about to see on disk anyway. What a
    // decision needs is: where it lands, what the index row says, what is wrong.
    process.stdout.write(`would create ${out.path}\n`);
    if (out.index && out.index.line) process.stdout.write(`index row     ${out.index.line}\n`);
    if (out.collision) process.stdout.write(`⚠️  collision  "${out.collision.identity || ""}" already exists as ${out.collision.with}\n`);
    for (const w of out.warnings || []) process.stdout.write(`⚠️  ${w}\n`);
    const head = String(out.content).split("\n").slice(0, 8).join("\n");
    process.stdout.write(`\n${head}\n…\n\n--write to create it · --json for the full payload\n`);
    return;
  }
  if (out.collision) {
    fail(`topic collision: "${out.collision.identity || kind}" already exists as ${out.collision.with}. ` +
         "Extend that artifact, or pick a different title.");
  }
  if (existsSync(out.path)) fail(`refusing to overwrite ${out.path}`);
  mkdirSync(dirname(out.path), { recursive: true });
  // sweep:false — this directory is not reconcile's own regeneration loop,
  // so there is no reason to pay for scanning it for orphaned temps here.
  writeFileAtomic(out.path, out.content, { sweep: false });
  process.stdout.write(`created ${out.path}\n`);
  for (const w of out.warnings || []) process.stdout.write(`⚠️  ${w}\n`);
  // The index row and the board are derived views: regenerate rather than
  // patch, so a hand-edit can never leave them permanently out of step. The
  // artifact is already on disk at this point, so a reconcile failure must be
  // reported against it rather than exiting as if the write had not happened.
  reconcileAfterWrite();
}

function reconcileAfterWrite() {
  const r = spawnSync(process.execPath, [SCRIPT("reconcile"), "--write"], {
    encoding: "utf8", env: { ...process.env, WAYPOST_HOME: ROOT },
  });
  let failed = [];
  let did = null;
  try {
    const out = JSON.parse(r.stdout || "{}");
    failed = [out.kanban, out.codemap, out.graph, ...(out.indexes || [])]
      .filter((t) => t && t.error).map((t) => `${t.path || t.target || "?"}: ${t.error}`);
    // Name only the views that were actually (re)written: the message used to
    // claim "code-map, graph" even on a fresh vault where both are skipped by
    // design, one line above doctor's own "No graph.md yet" (E-2).
    const wrote = [];
    if ((out.indexes || []).some((t) => t && t.written)) wrote.push("indexes");
    for (const k of ["kanban", "codemap", "graph"]) if (out[k] && out[k].written) wrote.push(k === "codemap" ? "code-map" : k);
    did = wrote;
  } catch { /* fall through to the exit code */ }
  if (r.status === 0 && !failed.length) {
    process.stdout.write(did && did.length
      ? `derived views reconciled (${did.join(", ")})\n`
      : did ? "derived views already up to date\n"
      : "derived views reconciled\n");
    return;
  }
  process.stderr.write("waypost: the artifact was written, but reconciling the derived views failed:\n"
    + (failed.length ? failed.map((f) => `  ${f}\n`).join("") : `  ${(r.stderr || "").trim()}\n`)
    + "  fix the cause, then run `waypost reconcile --write`.\n");
  process.exitCode = 1;
}

// ─── story gates ───────────────────────────────────────────────────────

async function handleStory(args) {
  const [mode, storyPath] = positionals(args);
  if (!["plan", "close"].includes(mode) || !storyPath) {
    fail("story <plan|close> <story-path> [--write]");
  }
  const out = runJson("story-section", [mode, storyPath]);
  if (!flag(args, "--write")) {
    process.stdout.write(JSON.stringify({ ...out, content: undefined }, null, 2) + "\n");
    process.stdout.write("(preview only — re-run with --write to apply)\n");
    return;
  }
  // story-section.mjs will transform any file with a frontmatter block, not
  // only a real vault story — refuse to write anywhere outside the bound
  // vault rather than trust a positional path the caller supplied.
  const cfg = readConfig();
  if (!cfg || !cfg.vault_path || !isInsideVault(resolve(out.path), cfg.vault_path)) {
    fail(`refusing to write outside the vault: ${out.path}`);
  }
  if (!out.changed) { process.stdout.write(`unchanged ${out.path}\n`); return; }
  // Re-check against the file story-section actually read: between that read
  // and this write another session (or a hand edit) may have changed it, and
  // `content` was computed from the OLD bytes — writing it now would silently
  // discard the concurrent edit.
  let current;
  try { current = readFileSync(out.path, "utf8"); } catch (e) { fail(`${out.path}: ${e.message}`); }
  if (createHash("sha256").update(current, "utf8").digest("hex") !== out.original_sha256) {
    fail(`${out.path} changed since it was read — re-run`);
  }
  // sweep:false — same reasoning as handleDraft's write.
  // Loaded here, not at the top: this is its only caller, and a static import
  // linked the whole team graph into every command. No try/catch — if the
  // team code cannot load, the gate must refuse, not be skipped.
  const { withTeamArtifactGate } = await import(SCRIPT_URL("team-legacy"));
  withTeamArtifactGate(cfg.vault_path,out.path,mode,()=>{
    const latest=readFileSync(out.path,'utf8');
    if(createHash('sha256').update(latest,'utf8').digest('hex')!==out.original_sha256)throw new Error('story-changed-before-write');
    writeFileAtomic(out.path, out.content, { sweep: false });
  });
  process.stdout.write(`${mode}  ${out.path}\n  ${(out.notes || []).join("\n  ")}\n`);
  // Opening a story claims it for this session; closing it releases the claim.
  // Other harnesses on the same vault read that registry, so the gate is also
  // the announcement — nobody has to remember a separate command.
  claimForStory(mode === "plan" ? out.path : null, cfg.vault_path);
  reconcileAfterWrite();
}

function claimForStory(storyPath, vault) {
  // Warn, do not refuse: re-planning a story someone else opened changes the
  // file idempotently, and the moment that actually needs a gate is the commit.
  // But the session that is about to duplicate work should hear about it here.
  if (storyPath) {
    const r = spawnSync(process.execPath, [SCRIPT("sessions"), "--json"], {
      encoding: "utf8", env: { ...process.env, WAYPOST_HOME: ROOT },
    });
    try {
      const { claims = [], session_id: self } = JSON.parse(r.stdout || "{}");
      const ref = storyRefOf(storyPath, vault);
      const others = ref ? claims.filter((c) => c.story === ref && c.session !== self) : [];
      if (others.length) {
        process.stderr.write(`⚠️  ${ref} is already claimed by ${others.map((o) => `${o.session} (${o.harness || "?"})`).join(", ")}`
          + " — two sessions on one story is how the same work gets done twice.\n");
      }
    } catch { /* the registry is advisory; never block the gate on it */ }
  }
  const args = storyPath ? ["--claim", storyPath] : ["--release"];
  const r = spawnSync(process.execPath, [SCRIPT("sessions"), ...args], {
    encoding: "utf8", env: { ...process.env, WAYPOST_HOME: ROOT },
  });
  if (r.error || r.status !== 0) {
    const reason = r.error?.message || (r.stderr || "").split("\n").find((l) => /^(Error:|waypost)/.test(l)) || `exit ${r.status}`;
    process.stderr.write(`waypost story: story updated, but ${storyPath ? "claim" : "release"} failed; coordination is incomplete.\n`
      + (storyPath ? "Retry the story command" : "Retry with `waypost sessions --release`")
      + " with write access to the coordination directory (normally .git/waypost).\n"
      + `${reason}\n`);
  }
  const line = (r.stdout || "").split("\n").find((l) => l.startsWith("claimed") || l.startsWith("released"));
  if (line) process.stdout.write(`  ${line.trim()}  (visible to other sessions via \`waypost sessions\`)\n`);
}

// ─── derived views ─────────────────────────────────────────────────────

const DERIVED = { kanban: "kanban", graph: "graph", codemap: "codemap" };

// A graph or an index grows with the vault: at 200 artifacts graph.md is ~13k
// tokens and an index ~10k. Reading either whole to answer one question is the
// single largest avoidable cost on a big project, so the CLI answers the
// question instead — the derived views stay the source, this is just a lens.
function handleGraphQuery(target, args) {
  const cfg = readConfig();
  if (!cfg || !cfg.vault_path) fail("no bound vault — run `waypost bind <vault-path>` first");
  const p = join(cfg.vault_path, "graph.md");
  if (!existsSync(p)) fail("no graph.md yet — run `waypost graph`");
  const needle = target.replace(/\\/g, "/").replace(/^\.\//, "");
  const lines = readFileSync(p, "utf8").split("\n");
  const hits = lines.filter((l) => l.includes(needle) && l.startsWith("|"));
  if (!hits.length) {
    fail(`no node or edge mentions "${needle}" in graph.md.\n`
      + "       Nodes are keyed by vault-relative path (adr/foo.md), not by slug.");
  }
  const node = hits.filter((l) => !/\|\s*(supersedes|superseded_by|covers|covered_by|contains|part_of|links|link)\s*\|/i.test(l));
  const edges = hits.filter((l) => !node.includes(l));
  process.stdout.write(`${needle}\n`);
  for (const l of node) process.stdout.write(`  ${l.replace(/^\|\s*/, "").replace(/\s*\|\s*$/, "").replace(/\s*\|\s*/g, " · ")}\n`);
  if (edges.length) {
    process.stdout.write(`\nedges (${edges.length}):\n`);
    for (const l of edges.slice(0, 60)) {
      process.stdout.write(`  ${l.replace(/^\|\s*/, "").replace(/\s*\|\s*$/, "").replace(/\s*\|\s*/g, " → ")}\n`);
    }
    if (edges.length > 60) process.stdout.write(`  …and ${edges.length - 60} more\n`);
  }
}

// Vault-wide search that returns pointers, not documents: path, title, status
// and the matching line. The alternative an agent falls back to is grep plus a
// handful of full-file reads.
function handleSearch(args) {
  const cfg = readConfig();
  if (!cfg || !cfg.vault_path) fail("no bound vault — run `waypost bind <vault-path>` first");
  const terms = positionals(args);
  if (!terms.length) fail('search "<text>" [--kind adr|spec|epic|story|…] [--limit 20]');
  const kind = opt(args, "--kind");
  const limitRaw = opt(args, "--limit", "20");
  const limit = Number(limitRaw);
  if (!Number.isInteger(limit) || limit <= 0) fail(`--limit must be a positive integer, got "${limitRaw}"`);
  const re = new RegExp(terms.map((t) => t.replace(/[.*+?^${}()|[\]\\]/g, "\\$&")).join("|"), "i");
  const out = [];
  // iCloud leaves a placeholder — ".<name>.icloud" — for a file evicted from
  // local storage; the real name never appears in the listing until it syncs
  // back down. Counted, not searched: its content is not on disk to match.
  const notDownloaded = [];
  const walk = (dir, rel) => {
    let names = [];
    try { names = readdirSync(dir); } catch { return; }
    for (const n of names) {
      if (n.startsWith(".")) {
        const icloud = /^\.(.+)\.icloud$/.exec(n);
        if (icloud) notDownloaded.push(rel ? `${rel}/${icloud[1]}` : icloud[1]);
        continue;
      }
      const abs = join(dir, n);
      const r = rel ? `${rel}/${n}` : n;
      let lst; try { lst = lstatSync(abs); } catch { continue; }
      // A symlinked directory is never descended into: cheap protection
      // against a cycle (a directory symlinked into itself or an ancestor),
      // at the cost of not walking a legitimate symlinked subtree. A
      // symlinked FILE falls through to the same read path as a real one.
      if (lst.isSymbolicLink()) {
        let target; try { target = statSync(abs); } catch { continue; }
        if (target.isDirectory()) continue;
      } else if (lst.isDirectory()) {
        walk(abs, r);
        continue;
      } else if (!lst.isFile()) {
        continue;
      }
      if (!n.endsWith(".md")) continue;
      if (["kanban.md", "graph.md", "code-map.md"].includes(n)) continue;
      let text; try { text = readFileSync(abs, "utf8"); } catch { continue; }
      // parseFrontmatter, not an inline \n-only regex: a CRLF or BOM file
      // (the exact shape doctor's own cross-OS checks exist to catch before
      // it is fixed) used to read as "no frontmatter at all" here, so
      // `--kind` silently dropped every match and title/status came back
      // from the filename instead of the artifact's own fields.
      const fm = parseFrontmatter(text).data;
      if (kind && String(fm.type ?? "") !== kind) continue;
      const lines = text.split("\n");
      const hitLine = lines.findIndex((l) => re.test(l));
      if (hitLine === -1 && !re.test(r)) continue;
      out.push({ path: r, title: String(fm.title ?? "") || n, status: fm.status == null ? "" : String(fm.status),
        line: hitLine === -1 ? null : `${hitLine + 1}: ${lines[hitLine].trim().slice(0, 120)}` });
    }
  };
  walk(cfg.vault_path, "");
  if (!out.length) { process.stdout.write("no match\n"); }
  else {
    for (const h of out.slice(0, limit)) {
      process.stdout.write(`${h.path}${h.status ? `  (${h.status})` : ""}\n  ${h.title}\n`
        + (h.line ? `  ${h.line}\n` : ""));
    }
    if (out.length > limit) process.stdout.write(`…and ${out.length - limit} more (--limit)\n`);
  }
  if (notDownloaded.length) {
    process.stdout.write(`${notDownloaded.length} file(s) not downloaded from iCloud — open them once to sync\n`);
  }
}

function handleDerived(cmd, args) {
  if (flag(args, "--json")) { process.stdout.write(run(cmd, [], { capture: true })); return; }
  const out = runJson("reconcile", ["--write", "--only", DERIVED[cmd]]);
  const target = out[cmd] || {};
  if (target.error) fail(`${cmd}: ${target.error}`);
  if (target.skipped) { process.stdout.write(`${cmd}: ${target.skipped}\n`); return; }
  process.stdout.write(`${target.written ? "written" : "unchanged"} ${target.path || cmd}\n`);
}

// `waypost reconcile` is listed beside kanban/graph/codemap, so it answers in
// the same voice — a line per view — instead of the raw JSON its programmatic
// callers (draft, commit, the merge driver) consume. `--json` still yields that
// shape for anyone composing it.
function handleReconcile(args) {
  if (flag(args, "--json")) { process.stdout.write(run("reconcile", args.filter((a) => a !== "--json"), { capture: true })); return; }
  const wrote = flag(args, "--write");
  const out = runJson("reconcile", args);
  const line = (label, t) => {
    if (!t) return;
    if (t.error) { process.stdout.write(`  ${label}: error — ${t.error}\n`); return; }
    if (t.skipped) { process.stdout.write(`  ${label}: ${t.skipped}\n`); return; }
    process.stdout.write(`  ${label}: ${t.written ? "written" : "unchanged"}${t.path ? ` ${t.path}` : ""}\n`);
  };
  process.stdout.write(`${wrote ? "reconciled" : "dry run (nothing written; add --write)"}\n`);
  line("kanban", out.kanban);
  line("code-map", out.codemap);
  line("graph", out.graph);
  for (const idx of out.indexes || []) line(idx.path || "index", idx);
  if (out.summary && out.summary.failed > 0) process.exitCode = 1;
}

// ─── prompts & skills ──────────────────────────────────────────────────

function printDoc(dir, name, suffix) {
  const base = join(ROOT, dir);
  const names = readdirSync(base)
    .map((n) => n.replace(/\.md$/, ""))
    .filter((n) => !n.startsWith("."))
    .sort();
  if (!name) {
    process.stdout.write(`${dir}:\n  ${names.join("\n  ")}\n\nPrint one with: waypost ${dir === "prompts" ? "prompt" : "skill"} <name>\n`);
    return;
  }
  // A name, never a path: `waypost prompt ../README` used to print whatever the
  // traversal landed on.
  if (!/^[\w.-]+$/.test(name) || name.includes("..")) fail(`not a valid name: ${name}`);
  // Bundled skills carry the waypost- prefix (the standard wants a name
  // that is unique across every skill a harness loads); the short name
  // still works here.
  if (suffix && !existsSync(join(base, name, suffix)) && existsSync(join(base, `waypost-${name}`, suffix))) name = `waypost-${name}`;
  const p = suffix ? join(base, name, suffix) : join(base, `${name}.md`);
  if (!existsSync(p)) fail(`no such ${dir === "prompts" ? "prompt" : "skill"}: ${name} (have: ${names.join(", ")})`);
  process.stdout.write(readFileSync(p, "utf8"));
}

// ─── profile ─────────────────────────────────────────────────────────────
//
// WP-17, the discovery story, ADR Decision 2: the machine and project
// profiles — the scheme of what waypost works with. discovery.mjs is
// compute only (detection, asking, no fs writes); this is the one place
// that reads the previous profile, decides whether it is due (missing,
// older than 30 days, or --refresh — discovery.mjs's needsRefresh), rebuilds
// it, and writes it back atomically — the same division every other write
// in this file keeps with its scripts/*.mjs collaborator. Shared by
// `waypost profile` and `waypost setup`'s own discovery step, so both apply
// the exact same refresh rule.
async function refreshProfiles({ force = false } = {}) {
  const discovery = await import(SCRIPT_URL("discovery"));
  const toolchains = await import(SCRIPT_URL("toolchains"));
  const presence = await import(SCRIPT_URL("presence"));
  const root = projectRoot();
  const host = presence.hostSlug();
  const home = homedir();
  const reg = toolchains.loadRegistry({ projectRoot: root, platform: process.platform });

  const machinePath = discovery.machineProfilePath({ home, host });
  // A profile that exists but does not parse is treated exactly like a
  // missing one — needsRefresh(null, …) is always true — so a hand-edited or
  // half-written file is silently repaired on the next refresh rather than
  // wedging this command the way an unreadable projectstore.json must not.
  const load = (p) => {
    if (!existsSync(p)) return null;
    try { return JSON.parse(readFileSync(p, "utf8")); } catch { return null; }
  };

  let machine = load(machinePath);
  const machineRefreshed = discovery.needsRefresh(machine, { force });
  if (machineRefreshed) {
    machine = discovery.buildMachineProfile(reg.entries, { home, host });
    mkdirSync(dirname(machinePath), { recursive: true });
    writeFileAtomic(machinePath, JSON.stringify(machine, null, 2) + "\n");
  }

  // Item 6: a project AT $HOME (no project bound, cwd left at the user's
  // home, WAYPOST_PROJECT_DIR unset or pointed at ~) must never get a
  // project.<host>.json written into ~/.waypost/state/ — the same "no
  // project here" `waypost size --project` already enforces by refusing to
  // scan $HOME (scripts/sizes.mjs). No project profile is built at all.
  const noProject = resolve(root) === resolve(home);
  let project = null, projectPath = null, projectRefreshed = false;
  if (!noProject) {
    projectPath = discovery.projectProfilePath({ projectRoot: root, host });
    project = load(projectPath);
    projectRefreshed = discovery.needsRefresh(project, { force });
    if (projectRefreshed) {
      project = discovery.buildProjectProfile(reg.entries, { projectRoot: root, host });
      mkdirSync(dirname(projectPath), { recursive: true });
      writeFileAtomic(projectPath, JSON.stringify(project, null, 2) + "\n");
    }
  }

  return { host, machine, machinePath, machineRefreshed, project, projectPath, projectRefreshed, noProject, notes: reg.notes };
}

async function handleProfile(args) {
  let r;
  try {
    r = await refreshProfiles({ force: flag(args, "--refresh") });
  } catch (e) { fail(`profile: ${e.message}`); }

  if (flag(args, "--json")) {
    process.stdout.write(JSON.stringify({ machine: r.machine, project: r.noProject ? null : r.project, notes: r.notes }, null, 2) + "\n");
    return;
  }

  process.stdout.write(`host  ${r.host}\n`);
  process.stdout.write(`machine  ${tildeHome(r.machinePath)}  (${r.machineRefreshed ? "refreshed" : "kept"}, ${r.machine.generated_at})\n`);
  process.stdout.write(`  ${r.machine.platform}/${r.machine.arch}\n`);
  for (const t of r.machine.tools) process.stdout.write(`  tool       ${t.name} (${t.id})  ${t.bin}\n`);
  for (const c of r.machine.caches) {
    process.stdout.write(`  cache      ${tildeHome(c.path)}  [${c.tool} · ${c.source}]${c.ask_note ? `  (asked: ${c.ask_note})` : ""}\n`);
  }
  if (r.noProject) {
    process.stdout.write("no project here — machine profile only\n");
  } else {
    process.stdout.write(`project  ${tildeHome(r.projectPath)}  (${r.projectRefreshed ? "refreshed" : "kept"}, ${r.project.generated_at})\n`);
    for (const e of r.project.ecosystems) process.stdout.write(`  ecosystem  ${e.name} (${e.id})  ${e.manifest}\n`);
  }
  // ADR Decision 1: a project's own .waypost/toolchains/ entry may only be
  // data — every dropped field is a project author reaching for something
  // this profile refuses to run, so it belongs here, not just in doctor.
  if (r.notes.length) {
    process.stdout.write(`\n${r.notes.length} note(s) from .waypost/toolchains/:\n`);
    for (const n of r.notes) process.stdout.write(`  ${n.file}${n.field ? ` (${n.field})` : ""}: ${n.reason}\n`);
  }
}

// ─── size ──────────────────────────────────────────────────────────────
//
// Read-only measurement of build artifacts and dev caches (WP-17, "Disk
// hygiene by discovery"): never writes, never deletes. A dynamic
// import(), the way selfInstall reaches agents.mjs above — in-process, not
// a subprocess — so a later `doctor` check can share this exact code.
const GB = 1024 ** 3;

function tildeHome(p) {
  const home = homedir();
  return p === home || p.startsWith(home + sep) ? `~${p.slice(home.length)}` : p;
}

async function handleSize(args) {
  let sizes, toolchains;
  try {
    sizes = await import(SCRIPT_URL("sizes"));
    toolchains = await import(SCRIPT_URL("toolchains"));
  } catch (e) { fail(`size: ${e.message}`); }
  const json = flag(args, "--json");

  if (flag(args, "--global")) {
    // WP-18 Decision 4: a whole-disk scan is heavy work too, so it holds a
    // machine-wide slot exactly like `waypost run --heavy` — same refusal
    // (exit 75), same reason and retry line. No `fail()` (process.exit)
    // between the claim and the finally below, so the slot is always
    // released, even when the scan itself throws.
    let capacity, presence;
    try {
      capacity = await import(SCRIPT_URL("capacity"));
      presence = await import(SCRIPT_URL("presence"));
    } catch (e) { fail(`size --global: ${e.message}`); }
    const dir = slotsDir(presence);
    try { ensureMachineStateDir(dir); } catch (e) { fail(`size --global: ${stateWriteHint(dir, e)}`); }
    const where = slotWhere(process.cwd());
    const claim = await claimSlot(dir, ["waypost", "size", "--global"], capacity, presence, where);
    if (!claim.ok) {
      process.stderr.write(`waypost size --global: refused — ${claim.reason}\n  retry: waypost size --global\n`);
      process.exitCode = EX_TEMPFAIL;
      return;
    }
    // Same as run --heavy: the authority goes into the record after the lock
    // is released, never before it (third amendment).
    recordAuthority(claim.file, capacity);
    let out, reg, error, usedProfile = false;
    try {
      reg = toolchains.loadRegistry({ projectRoot: projectRoot(), platform: process.platform });
      // WP-17, the discovery story: a fresh machine profile for THIS host and
      // platform (built by `waypost profile`/`waypost setup`, never here —
      // `size` stays read-only, Decision 3 of the ADR) is measured directly;
      // otherwise today's path, unchanged. A profile is never rebuilt or
      // refreshed by this command.
      const discovery = await import(SCRIPT_URL("discovery"));
      const host = presence.hostSlug();
      const machinePath = discovery.machineProfilePath({ home: homedir(), host });
      let machine = null;
      if (existsSync(machinePath)) {
        try { machine = JSON.parse(readFileSync(machinePath, "utf8")); } catch { machine = null; }
      }
      // Item 7: a profile missing its own `caches` array (corrupt, or an
      // older shape from before the fact-only profile) is not "fresh" —
      // fall back to the registry entirely rather than measure nothing.
      const fresh = machine && machine.platform === process.platform
        && Array.isArray(machine.caches) && !discovery.needsRefresh(machine, {});
      // The registry travels WITH the profile (ADR Decision 2): a profile
      // holds facts only (tool/item/path/source), never clean/regenerable/
      // confidence/docs/notes — scanGlobal reattaches that policy from
      // THIS, the current, registry, matched by (tool, item), so a fixed
      // `regenerable` or `clean` is visible here at once, never stale for
      // up to 30 days waiting on the next profile refresh.
      out = fresh ? sizes.scanGlobal({ profile: machine, registry: reg }) : sizes.scanGlobal({ registry: reg });
      usedProfile = Boolean(fresh);
    } catch (e) {
      error = e;
    } finally {
      claim.release();
    }
    if (error) fail(`size --global: ${error.message}`);
    if (json) {
      process.stdout.write(JSON.stringify({
        caches: out, notes: reg.notes, profile_used: usedProfile,
        ...(usedProfile && out.dropped ? { profile_stale_items: out.dropped } : {}),
      }, null, 2) + "\n");
      return;
    }
    if (!usedProfile) {
      process.stdout.write("no fresh machine profile for this host — measuring the shipped registry's own defaults (waypost profile to build one)\n");
    } else if (out.dropped) {
      process.stdout.write(`${out.dropped} cache item(s) in the profile are no longer in the registry — registry changed — waypost profile --refresh\n`);
    }
    const threshold = 0.1 * GB;
    const big = out.filter((e) => e.bytes >= threshold).sort((a, b) => b.bytes - a.bytes);
    if (!big.length) { process.stdout.write("no caches at or above 0.1 GB found (waypost size --global --json for the rest)\n"); }
    for (const e of big) {
      process.stdout.write(`  ${(e.bytes / GB).toFixed(1)} GB  ${tildeHome(e.path)}  [${e.tool} · ${e.source}]\n    → ${e.clean}\n`);
    }
    const small = out.length - big.length;
    if (small > 0) process.stdout.write(`…and ${small} more below 0.1 GB (--json for all)\n`);
    if (reg.notes.length) process.stdout.write(`\n${reg.notes.length} note(s) from .waypost/toolchains/ (--json for detail)\n`);
    return;
  }

  const bi = args.indexOf("--budget");
  let budget = null;
  if (bi !== -1) {
    const v = args[bi + 1];
    if (v === undefined) fail("--budget requires a value");
    budget = Number(v);
    if (!Number.isInteger(budget) || budget < 0) fail(`--budget must be a non-negative integer, got "${v}"`);
  }

  // A local extractor: the shared opt() does not know --project's value is
  // optional, and would swallow --json as the directory (A-8's own lesson,
  // applied here rather than reused, since --project's arity differs from
  // every other flag in VALUED).
  const pi = args.indexOf("--project");
  const dir = pi !== -1 && args[pi + 1] !== undefined && !args[pi + 1].startsWith("--")
    ? resolve(expandHome(args[pi + 1]))
    : projectRoot();

  let out, reg;
  try {
    reg = toolchains.loadRegistry({ projectRoot: dir, platform: process.platform });
    out = sizes.scanProject(dir, { budget, registry: reg });
  } catch (e) { fail(`size: ${e.message}`); }

  // waypost-removing/'s own size (the amended machine-wide-limit ADR): never
  // part of the project scan itself (scanProject never enters a git
  // directory), reported here as a courtesy — it holds items already handed
  // to the detached deleter, on their way out.
  let removingBytes = null;
  try {
    const common = slotWhere(dir).common;
    if (common) {
      const removingPath = join(common, REMOVING_DIR);
      if (existsSync(removingPath)) removingBytes = sizes.inspectDir(removingPath, {}).bytes ?? null;
    }
  } catch { /* best effort */ }

  if (json) { process.stdout.write(JSON.stringify({ ...out, notes: reg.notes, waypost_removing_bytes: removingBytes }, null, 2) + "\n"); return; }

  const totalGb = (out.bytes_at_least / GB).toFixed(1);
  if (out.complete) {
    process.stdout.write(`${totalGb} GB\n`);
  } else {
    process.stdout.write(`≥ ${totalGb} GB (stopped after ${out.entries_visited} entries — `
      + "the entry budget; waypost size --budget <n> to raise it)\n");
  }
  if (removingBytes != null) {
    process.stdout.write(`  ${(removingBytes / GB).toFixed(2)} GB  waypost-removing/ (already handed to the deleter)\n`);
  }
  const sorted = [...out.dirs].sort((a, b) => b.bytes - a.bytes);
  if (!sorted.length) { process.stdout.write("no build artifacts found\n"); return; }
  for (const d of sorted) {
    const abs = resolve(out.root, d.path || ".");
    process.stdout.write(`  ${(d.bytes / GB).toFixed(1)} GB  ${tildeHome(abs)}${d.partial ? "  (partial)" : ""}\n`);
  }
}

// ─── clean ───────────────────────────────────────────────────────────────
//
// waypost clean [--json] — WP-17, the clean-plan story (ADR "Disk hygiene by
// discovery" Decision 4). A classified plan over both scopes at once: the
// project (walked with rootItem:false — the project root is never an item —
// and the entry budget `size` itself uses) and the machine (a fresh
// profile's own caches, plus any registry cache the profile does not carry
// yet, the same static fallback `size --global` uses without one). Every
// fact classification needs — git ignore/tracked status, the live process
// table, leases, whether another host shares this checkout — is gathered
// HERE and handed to the pure scripts/cleanup.mjs; nothing there ever
// touches the filesystem or a subprocess. Holds the machine-wide slot the
// whole time it runs, exactly like `size --global` (WP-18 Decision 4): a
// plan is itself a scan of the whole machine's caches.
//
// waypost clean --apply <id…>|should [--yes --reason "…"] — the removal
// story (Decision 5, and its amendment for the standing yes at the end of
// `run --heavy`, which does not apply here — every apply here needs its own
// yes). Removal itself lives ENTIRELY in this file: scripts/cleanup.mjs and
// scripts/sizes.mjs carry the same two guards forbidding a removal call or
// a quoted removal word, so this is the only place any of it can happen.

// WAYPOST_CLEAN_NOW overrides "now" for hermetic tests only — ctime cannot be
// backdated on a fixture, so a test instead moves the clock forward past
// stale_days. Honored only under NODE_TEST_CONTEXT — the marker `node --test`
// sets on itself and every child process it spawns (never set otherwise, and
// never something a real invocation could set by accident) — so a variable
// leaked into an interactive shell can never misdate a real plan; ignored
// with a warning on stderr instead. Warned at most once either way, the
// same way WAYPOST_CAPACITY_PROBE is (warnIfProbed above).
let warnedCleanNowProbed = false;
// Whether the last cleanNow() call actually used WAYPOST_CLEAN_NOW (never
// set, no NODE_TEST_CONTEXT, or unparseable all leave this false) — read by
// every log-writing call site below so the log's own `clock` field never
// claims an override that was silently ignored.
let lastCleanNowHonored = false;
function cleanNow() {
  const raw = process.env.WAYPOST_CLEAN_NOW;
  if (!raw) { lastCleanNowHonored = false; return Date.now(); }
  if (!process.env.NODE_TEST_CONTEXT) {
    lastCleanNowHonored = false;
    if (!warnedCleanNowProbed) {
      warnedCleanNowProbed = true;
      process.stderr.write("waypost: WAYPOST_CLEAN_NOW is set but NODE_TEST_CONTEXT is not — ignored (tests only)\n");
    }
    return Date.now();
  }
  const n = Number(raw);
  const ms = Number.isFinite(n) ? n : Date.parse(raw);
  if (!Number.isFinite(ms)) { lastCleanNowHonored = false; return Date.now(); }
  lastCleanNowHonored = true;
  if (!warnedCleanNowProbed) {
    warnedCleanNowProbed = true;
    process.stderr.write("waypost: WAYPOST_CLEAN_NOW is set — the clock is not the real one (tests only)\n");
  }
  return ms;
}

// Whether a harness is running right now, checked the way the machine-wide-
// limit ADR's own gate checks it: WAYPOST_HARNESS is never trusted alone to
// say "no harness" (it could just be unset by whatever is asking) — the
// SAME detection is also run with it forced empty, so the real process
// ancestry and the registry's own env markers still have their say either
// way. Any failure along the way (the agents module itself, or the
// detection call) is read as "no harness detected" — the terminal check is
// the other half of this gate, so a session with neither a TTY nor a
// harness still needs --yes --reason regardless.
async function isHarnessDetected() {
  try {
    const agents = await import(SCRIPT_URL("agents"));
    if (agents.detectHarness(process.env) !== "unknown") return true;
    if (agents.detectHarness({ ...process.env, WAYPOST_HARNESS: "" }) !== "unknown") return true;
    return false;
  } catch {
    return false;
  }
}

// Gathers every project- and machine-scope item, plus every fact
// classification needs, once — the plan, `--apply` and `setup`'s own audit
// all build from this same context, so "should" always re-plans against the
// current state rather than a stale earlier run. `budget` bounds the
// project walk the way `waypost size` itself can be bounded (`clean` stays
// unbounded, its own existing behaviour; `setup`'s audit passes
// DEFAULT_ENTRY_BUDGET, the same fixed count `doctor` uses, so it stays
// deterministic there too). `includeMachine: false` skips the machine scope
// entirely — no profile read, no cache candidates resolved — for a caller
// that already knows this run has nothing fresh to say about it (`setup`,
// when discovery did not just refresh the machine profile).
// `root`/`vault` (the amended machine-wide-limit ADR's automatic path):
// override the project root and the vault instead of deriving them from
// projectRoot()/readConfig() — the automatic path may call neither
// (readConfig() calls fail(), which exits the process, and projectRoot()
// would read whatever WAYPOST_PROJECT_DIR happens to be at the MOMENT this
// runs, when autoCleanup wants the root it already resolved via slotWhere).
// `"vault" in opts` distinguishes "the caller resolved vault by hand, even
// to null" from "the caller never mentioned it" — handleClean and setup's
// own audit never pass it, and keep today's readConfig()-based lookup.
// `walk` forwards straight to scanProject (stopAtGit/locators/deadline);
// every default reproduces today's behaviour exactly.
function gatherCleanContext({ cleanup, sizes, toolchains, presence, discovery }, opts = {}) {
  const { budget = null, includeMachine = true, walk = {} } = opts;
  const root = opts.root || projectRoot();
  const home = homedir();
  const stateDir = machineStateDir();
  const platform = process.platform;

  // The vault, if any — read early: a lease is stored keyed the same way
  // `presence.vaultRel` spells it (vault-relative when the leased path sits
  // inside the bound vault, project-relative otherwise), and that function
  // is one-way — resolving a lease's own string back to an absolute path
  // would be genuinely ambiguous (the same relative string can spell a real
  // path under EITHER root). Every project item is instead run through the
  // SAME vaultRel() a lease went through, and compared as strings — no
  // inversion needed either way.
  const vault = "vault" in opts ? opts.vault : (() => {
    const cfg = readConfig();
    return cfg && cfg.vault_path && existsSync(cfg.vault_path) ? cfg.vault_path : null;
  })();

  const reg = toolchains.loadRegistry({ projectRoot: root, platform });
  const metadataNames = sizes.metadataNamesOf(reg.entries);

  // A project root that is itself home, an ancestor of home, or a
  // filesystem/drive root can never be a project to scan — scanProject
  // itself throws for $HOME and "/" outright, and an ancestor of home is no
  // safer a target. Reusing cleanup.refusePath here (home only, no `root`/
  // `stateDir` — those would make every path trivially "refused") is the
  // same protected-path logic every item is already checked against. Plan
  // the machine scope only, rather than throwing `waypost clean` (or
  // setup's own audit) down with it — there being no project bound here is
  // an ordinary state, not a failure.
  const projectScopeRefused = cleanup.refusePath(root, { home, platform });

  // Project scope: the project root is never an item (rootItem: false); a
  // batched git check-ignore/ls-files over every match this walk found, once,
  // gives classification the ignored/tracked facts it needs per item. A
  // locator match's own `path` is already absolute (outside the project),
  // so it never enters that batch.
  let projectItems = [];
  let projectEcosystems = [];
  let scan = null;
  if (!projectScopeRefused) {
    scan = sizes.scanProject(root, {
      registry: reg, rootItem: false, budget,
      stopAtGit: walk.stopAtGit, locators: walk.locators, deadline: walk.deadline,
    });
    const relCandidates = scan.dirs.filter((d) => d.match !== "locator").map((d) => d.path);
    const gf = sizes.gitFacts(root, relCandidates);
    projectItems = scan.dirs.map((d) => {
      const abs = d.match === "locator" ? d.path : resolve(root, d.path);
      return {
        scope: "project", path: abs, rel: d.match === "locator" ? null : d.path,
        leaseRel: vault ? presence.vaultRel(abs, vault) : abs,
        bytes: d.bytes, newest_ms: d.newest_ms, nested_git: d.nested_git,
        in_nested_repo: d.in_nested_repo, unreadable: d.unreadable, other_fs: d.other_fs, partial: d.partial, match: d.match,
        tool: d.tool, origin: d.origin, regenerable: d.regenerable, stale_days: d.stale_days,
        clean: d.clean, clean_argv: d.clean_argv, dev: d.dev, ino: d.ino,
        auto: d.auto, holds_package: d.holds_package, package: d.package,
        ignored: d.match === "locator" ? undefined : gf.ignored.has(d.path),
        tracked: d.match === "locator" ? undefined : gf.tracked.has(d.path),
      };
    });
    // The project's own detected ecosystems (scripts/discovery.mjs) — a tag
    // or generic match carries no owning tool of its own (see
    // classifyItem's projectEcosystemRunning check), so this is the only
    // in-use signal available for either kind.
    projectEcosystems = discovery.detectManifests(reg.entries, { projectRoot: root });
  }

  // Machine scope: a fresh profile's own caches (facts only — policy is
  // reattached from THIS registry, same as `size --global`), plus any
  // registry cache item the profile does not carry — measured directly, the
  // static fallback path `size --global` uses without a profile at all.
  const host = presence.hostSlug();
  const machineItems = [];
  if (includeMachine) {
    const machinePath = discovery.machineProfilePath({ home, host });
    let machine = null;
    if (existsSync(machinePath)) {
      try { machine = JSON.parse(readFileSync(machinePath, "utf8")); } catch { machine = null; }
    }
    const freshProfile = machine && machine.platform === platform
      && Array.isArray(machine.caches) && !discovery.needsRefresh(machine, {});
    const profileCaches = freshProfile ? sizes.scanGlobal({ profile: machine, registry: reg, platform }) : [];
    const covered = new Set(profileCaches.map((c) => c.path));
    // Same (tool, item) key as a profile cache, covered at ITS path above —
    // used below to tell a genuinely separate static candidate apart from a
    // leftover at a tool's OLD default location after its cache moved.
    const coveredKeys = new Set(profileCaches.map((c) => `${c.tool}::${c.item}`));
    const staticCandidates = sizes.cacheCandidates({ home, env: process.env, platform, registry: reg })
      .filter((c) => !covered.has(c.path));
    const extraCaches = sizes.measureCaches(staticCandidates, { metadata: metadataNames });
    // The plain env/default path of every cache item, for comparing an
    // "asked" path against — computed once, resolved with no asking at
    // all, so an asked path that merely happens to agree with the default
    // is never treated as if it had moved (see routeFor's own
    // askedNonDefault check, decided here at plan time rather than only
    // discovered later at apply time).
    const defaultOnly = toolchains.resolveCachePaths(reg.entries, { home, env: process.env, platform, ask: false });
    const defaultPathsByKey = new Map();
    for (const c of defaultOnly) {
      const key = `${c.tool}::${c.item}`;
      if (!defaultPathsByKey.has(key)) defaultPathsByKey.set(key, new Set());
      defaultPathsByKey.get(key).add(c.path);
    }
    // `staleLeftover`: this candidate's own (tool, item) key is ALSO
    // resolved by the fresh profile, but at a DIFFERENT path — the tool's
    // cache moved, and this is what is left at the OLD default location.
    // Its own clean_argv would clean the tool's CURRENT (active) location,
    // never this one, so a route built from it would always be shown in
    // the plan and always skipped or fail at apply — clean_argv is
    // stripped here instead, so routeFor falls through to waypost's own
    // removal, the one route that actually reaches this specific path.
    const pushMachineItem = (c, { staleLeftover = false } = {}) => {
      const key = `${c.tool}::${c.item}`;
      const askedNonDefault = c.source === "asked" && !(defaultPathsByKey.get(key) || new Set()).has(c.path);
      machineItems.push({
        scope: "machine", path: c.path, rel: null,
        // `item` (the cache's own raw path template) and `source` ("asked"
        // vs. "env"/"default") are what the removal path re-checks a moved
        // cache and an asked-only path against — see machinePathStillSafe()
        // below. `askedNonDefault` is what routeFor itself already used to
        // decide the route shown in THIS plan.
        item: c.item ?? null, source: c.source ?? null, askedNonDefault,
        bytes: c.bytes, newest_ms: c.newest_ms,
        nested_git: false, in_nested_repo: false, unreadable: c.unreadable, other_fs: c.other_fs, partial: false, match: null,
        tool: c.tool, origin: null, regenerable: c.regenerable, stale_days: c.stale_days,
        clean: c.clean, clean_argv: staleLeftover ? null : c.clean_argv, clean_docs: c.clean_docs ?? null,
        manual: c.manual, dev: c.dev, ino: c.ino,
      });
    };
    for (const c of profileCaches) pushMachineItem(c);
    for (const c of extraCaches) pushMachineItem(c, { staleLeftover: coveredKeys.has(`${c.tool}::${c.item}`) });
  }

  // Facts outside the walk: the live process table (never on win32; null
  // either way when `ps` itself is unavailable or fails — presence.mjs's
  // own processTable() folds every such case into null, so `table === null`
  // is the one signal that means "no live process table, protection here is
  // by recent modification time only" — the plan's own inUseSignal below),
  // the other live sessions' leases on a path inside this project, and
  // whether a live session on another host shares this checkout — all
  // advisory, exactly as ADR-0007 already treats them, and all skipped
  // gracefully when there is no bound vault to read them from.
  const table = platform === "win32" ? null : presence.processTable();
  const comms = table ? [...table.values()].map((p) => p.comm).filter(Boolean) : [];
  const runningTools = cleanup.runningTools(reg.entries, comms);
  const projectEcosystemRunning = projectEcosystems.some((e) => runningTools.has(e.id));
  const inUseSignal = table ? "process-table" : "recency-only";

  let leases = [];
  let sharedProject = false;
  if (vault) {
    const sess = process.env.WAYPOST_SESSION_ID || null;
    leases = presence.readLeases(vault, { self: sess })
      .filter((l) => l.live && !l.mine)
      .map((l) => ({ path: l.path, session: l.session, host: l.host }));
    sharedProject = presence.sharedTree(vault, { self: sess }).shared;
  }

  return {
    root, home, stateDir, platform, vault, reg, metadataNames, host, scan,
    projectItems, machineItems, runningTools, leases, sharedProject,
    projectEcosystems, projectEcosystemRunning, inUseSignal,
  };
}

function factsFrom(ctx, now) {
  return {
    now, home: ctx.home, root: ctx.root, stateDir: ctx.stateDir, platform: ctx.platform,
    runningTools: ctx.runningTools, leases: ctx.leases, sharedProject: ctx.sharedProject,
    projectEcosystemRunning: ctx.projectEcosystemRunning,
  };
}

// `limit`/`shortfall`/`dev` (the amended machine-wide-limit ADR): the
// ACTIVE cleanup-limit setting, if any — activeLimitFor() below — so the
// manual plan's own `picked` marks exactly what the automatic path at the
// end of `waypost run --heavy` would pick right now, without ever renaming
// anything itself. Every other caller (setup's own audit, applyClean's
// re-plan for "should"/an id) omits them, unaffected: `picked` never
// changes an item's own class or route.
function planFromContext(ctx, cleanup, now, { limit = null, shortfall = 0, dev = null } = {}) {
  return cleanup.classify([...ctx.projectItems, ...ctx.machineItems], factsFrom(ctx, now), { now, limit, shortfall, dev });
}

// The setting `waypost clean --limit` last wrote for this host, resolved to
// exactly what classify()/pickUnderLimit() need: the limit itself, plus —
// only for `free:<P>%` — the shortfall against ONE `fs.statfsSync` reading
// of the root and the root's own device (cleanup.limitNeed's own device
// restriction). `off`, or no setting at all, is "no limit" — the same as
// never passing one.
function activeLimitFor(root, cleanup, presence) {
  const setting = readCleanupSetting({ host: presence.hostSlug() });
  if (!setting || !setting.limit || setting.limit.kind === "off") return { limit: null, shortfall: 0, dev: null };
  const limit = setting.limit;
  if (limit.kind !== "free") return { limit, shortfall: 0, dev: null };
  let shortfall = 0;
  let dev = null;
  try {
    const s = statfsSync(root);
    shortfall = cleanup.shortfallOf({ size: s.blocks * s.bsize, avail: s.bavail * s.bsize }, limit.percent);
  } catch { /* best effort — statfs failed, need reads as 0 */ }
  try { dev = lstatSync(root).dev; } catch { /* best effort — no device restriction without it */ }
  return { limit, shortfall, dev };
}

function formatPlanItem(it) {
  return {
    id: it.id, scope: it.scope, path: it.path, ...(it.rel ? { rel: it.rel } : {}),
    bytes: it.bytes, class: it.class, reason: it.reason, route: it.route,
    match: it.match, tool: it.tool, stale_days: it.stale_days, newest_ms: it.newest_ms,
    picked: it.picked,
    // A "can" item flagged manual has no route waypost will ever run — its
    // own clean/clean_docs are shown instead, so the plan itself carries
    // the instructions rather than only the reason it stopped there.
    ...(it.manual === true ? { manual: true } : {}),
    ...(it.clean ? { clean: it.clean } : {}),
    ...(it.clean_docs ? { clean_docs: it.clean_docs } : {}),
  };
}

function formatPlan(classified, ctx, now) {
  return {
    host: ctx.host, root: ctx.root, generated_at: new Date(now).toISOString(),
    in_use_signal: ctx.inUseSignal, items: classified.map(formatPlanItem),
  };
}

function printCleanPlan(result) {
  process.stdout.write(`host  ${result.host}\n`);
  process.stdout.write(`root  ${tildeHome(result.root)}\n`);
  if (result.in_use_signal === "recency-only") {
    process.stdout.write("(no live process table — in-use protection is by recent modification time only)\n");
  }
  if (result.leftovers && result.leftovers.handed_off.length) {
    process.stdout.write(`(${result.leftovers.handed_off.length} leftover item(s) from an interrupted run handed to the deleter)\n`);
  }
  let any = false;
  for (const cls of ["should", "can", "keep"]) {
    const items = result.items.filter((it) => it.class === cls).sort((a, b) => b.bytes - a.bytes);
    if (!items.length) continue;
    any = true;
    process.stdout.write(`\n${cls} (${items.length})\n`);
    for (const it of items) {
      const where = it.rel || tildeHome(it.path);
      process.stdout.write(`  ${it.id}  ${(it.bytes / GB).toFixed(2)} GB  [${it.scope}]  ${where}\n    ${it.reason}\n`);
      if (it.manual && it.clean) process.stdout.write(`    manual: ${it.clean}\n`);
    }
  }
  if (!any) process.stdout.write("\nnothing found\n");
}

// setup's own audit report: a count and a GB total per class, then the five
// largest items overall, whatever class they are in — the two things worth
// knowing before deciding whether to look further with `waypost clean`.
function printAuditSummary(classified, say, inUseSignal) {
  if (inUseSignal === "recency-only") {
    say("  (no live process table — in-use protection is by recent modification time only)");
  }
  for (const cls of ["should", "can", "keep"]) {
    const items = classified.filter((it) => it.class === cls);
    const gb = items.reduce((sum, it) => sum + (it.bytes || 0), 0) / GB;
    say(`  ${cls}  ${items.length} item(s), ${gb.toFixed(2)} GB`);
  }
  const largest = [...classified].sort((a, b) => b.bytes - a.bytes).slice(0, 5);
  if (largest.length) {
    say("  largest:");
    for (const it of largest) {
      const where = it.rel || tildeHome(it.path);
      const manualNote = it.manual && it.clean ? ` — manual: ${it.clean}` : "";
      say(`    ${(it.bytes / GB).toFixed(2)} GB  [${it.class}]  ${where}${manualNote}`);
    }
  }
}

// ─── --limit: parsing ───────────────────────────────────────────────────

// --limit takes an OPTIONAL value: `waypost clean --limit` alone prints the
// current setting. The shared opt() cannot express that — it fails outright
// with no value at all, and otherwise takes whatever token follows
// blindly, which would swallow `--json` in `clean --limit --json`. Parsed
// by hand instead: `--limit=<v>` inline, or the very next token, but ONLY
// when it does not itself look like a flag.
function limitFlagValue(args) {
  const { head } = splitAtTerminator(args);
  const eq = head.find((a) => a.startsWith("--limit="));
  if (eq) return { present: true, value: eq.slice("--limit=".length) };
  const i = head.indexOf("--limit");
  if (i === -1) return { present: false, value: null };
  const next = head[i + 1];
  if (next !== undefined && !next.startsWith("--")) return { present: true, value: next };
  return { present: true, value: null };
}

// ─── --apply: parsing and selecting ────────────────────────────────────

// `--apply` takes a variable number of positional values (ids, or the
// single word "should") rather than the shared opt()'s one-token shape, so
// it is parsed by hand: every token right after the flag, up to the next
// one starting with "--" or the end of argv.
function parseApplySelection(args) {
  const { head } = splitAtTerminator(args);
  const i = head.indexOf("--apply");
  if (i === -1) return null;
  const values = [];
  for (let j = i + 1; j < head.length; j++) {
    if (head[j].startsWith("--")) break;
    values.push(head[j]);
  }
  if (values.length === 0) return { mode: "empty" };
  if (values.length === 1 && values[0] === "should") return { mode: "should" };
  if (values.length === 1 && values[0] === "can") return { mode: "can" };
  return { mode: "ids", ids: values };
}

function selectionDescriptorOf(sel) {
  return sel.mode === "should" ? { mode: "should" } : { mode: "ids", ids: sel.ids };
}

// Resolves a selection against the CURRENT (just-built) plan: { toApply,
// refused }. Every refusal is named up front, before anything is even
// re-checked, let alone removed:
//   - "should": every item classified should right now, whatever id it has.
//   - an id absent from the plan: gone, or never something Waypost would
//     remove at all (a symlink/junction is never followed, so it never
//     became an item in the first place).
//   - a manual machine cache: refused, showing its own prose `clean` text —
//     manual items are never run, by id or otherwise.
//   - a keep item: refused with the plan's own reason.
//   - anything else (should or can, not manual): eligible — "can only by
//     id" is enforced by --apply can itself being refused outright, not
//     here.
function resolveApplySelection(classified, sel) {
  if (sel.mode === "should") {
    return { toApply: classified.filter((it) => it.class === "should"), refused: [] };
  }
  const byId = new Map(classified.map((it) => [it.id, it]));
  const toApply = [];
  const refused = [];
  for (const id of sel.ids) {
    const it = byId.get(id);
    if (!it) {
      refused.push({
        id, path: null, scope: null, bytes: null, class: null, route: null,
        reason: "not in the plan now: gone, or no longer a directory Waypost would remove — a symbolic link is never followed",
      });
      continue;
    }
    if (it.manual) {
      refused.push({ id, path: it.path, scope: it.scope, bytes: it.bytes, class: it.class, route: null, reason: it.clean || "manual — see its own instructions, never run automatically" });
      continue;
    }
    if (it.class === "keep") {
      refused.push({ id, path: it.path, scope: it.scope, bytes: it.bytes, class: it.class, route: it.route, reason: it.reason });
      continue;
    }
    toApply.push(it);
  }
  return { toApply, refused };
}

// Ancestors before descendants: sorted by path depth, so a directory chosen
// alongside one of its own subdirectories (a project and a machine item can
// coincide in principle) is always removed before whatever sits inside it.
function orderForRemoval(items) {
  return [...items].sort((a, b) => {
    const da = a.path.split(sep).length, db = b.path.split(sep).length;
    return da !== db ? da - db : (a.path < b.path ? -1 : a.path > b.path ? 1 : 0);
  });
}

function isDescendantOf(p, ancestor) {
  return p !== ancestor && p.startsWith(ancestor + sep);
}

// ─── recheck, right before touching anything ───────────────────────────

// Fresh facts for exactly one item: inspectDir for its own bytes/age/nested-
// repo/readability, gitFacts scoped to just this one path (project items
// only — a locator match lives outside the project, so its git status is
// not this repository's to answer), the live process table, leases and
// sharedTree — all re-read, never carried over from the plan.
function freshFactsFor(item, ctx, mods, now) {
  const { sizes, cleanup, presence } = mods;
  // keepSuffixes: without it inspectDir's own default (empty) means a
  // package that appeared since the plan was built could never be caught
  // by a re-check right before removal — the automatic path's own re-check
  // (autoCleanup) depends on this exactly as much as a manual --apply does.
  const inspected = sizes.inspectDir(item.path, { metadata: ctx.metadataNames, keepSuffixes: sizes.keepSuffixesOf(ctx.reg.entries) });
  let ignored, tracked;
  if (item.scope === "project" && item.match !== "locator" && inspected.exists && inspected.is_directory) {
    const rel = relative(ctx.root, item.path);
    const gf = sizes.gitFacts(ctx.root, [rel]);
    ignored = gf.ignored.has(rel);
    tracked = gf.tracked.has(rel);
  }
  const table = ctx.platform === "win32" ? null : presence.processTable();
  const comms = table ? [...table.values()].map((p) => p.comm).filter(Boolean) : [];
  const runningTools = cleanup.runningTools(ctx.reg.entries, comms);
  // Recomputed against this FRESH runningTools, not carried over from the
  // plan's own ctx.projectEcosystemRunning — a project ecosystem tool can
  // have started or stopped since the plan was built, and a tag/generic
  // match's only in-use signal (classifyItem) must reflect that.
  const projectEcosystemRunning = (ctx.projectEcosystems || []).some((e) => runningTools.has(e.id));
  let leases = [];
  let sharedProject = false;
  if (ctx.vault) {
    const sess = process.env.WAYPOST_SESSION_ID || null;
    leases = presence.readLeases(ctx.vault, { self: sess }).filter((l) => l.live && !l.mine)
      .map((l) => ({ path: l.path, session: l.session, host: l.host }));
    sharedProject = presence.sharedTree(ctx.vault, { self: sess }).shared;
  }
  const fresh = { ...inspected, ...(ignored !== undefined ? { ignored } : {}), ...(tracked !== undefined ? { tracked } : {}) };
  return { fresh, facts: factsFrom({ ...ctx, runningTools, leases, sharedProject, projectEcosystemRunning }, now) };
}

function recheckItem(item, ctx, mods, now) {
  const { fresh, facts } = freshFactsFor(item, ctx, mods, now);
  return { ...mods.cleanup.recheck(item, fresh, facts), fresh };
}

function findCacheDef(reg, toolId, itemKey) {
  if (!toolId || !itemKey) return null;
  const entry = reg.entries.find((e) => e.id === toolId);
  if (!entry) return null;
  return (entry.caches || []).find((c) => c.path === itemKey) || null;
}

// A machine cache's own path re-checked right before removing it: when the
// shipped entry has an `ask` AND the route about to run is the tool's own
// clean_argv, the tool is asked again, and a path it no longer reports is
// skipped rather than removed from under a moved cache. Re-asking is scoped
// to a clean_argv route specifically — that is the one route that hands off
// to the TOOL itself, so it is the one place it matters whether the tool
// would now target somewhere else; a waypost-remove route never runs the
// tool at all, and (per routeFor, scripts/cleanup.mjs, decided already at
// plan time via `askedNonDefault`) is only ever given to a path already
// known to match its own default resolution.
function machinePathStillSafe(item, ctx, mods, route) {
  if (item.scope !== "machine") return { ok: true };
  if (route && route.kind === "tool-clean-argv") {
    const def = findCacheDef(ctx.reg, item.tool, item.item);
    if (def && def.ask && Array.isArray(def.ask.argv) && def.ask.argv.length) {
      const bin = mods.discovery.findOnPath(def.ask.argv[0], { platform: ctx.platform, env: process.env });
      if (bin) {
        let asked;
        try { asked = mods.toolchains.askCache(def.ask, { bin, env: process.env, home: ctx.home, platform: ctx.platform }); }
        catch { asked = { ok: false }; }
        if (asked.ok && !asked.value.includes(item.path)) {
          return { ok: false, reason: "the tool now reports a different cache location — re-plan with `waypost clean`" };
        }
      }
    }
  }
  // Defense in depth: routeFor itself already refuses a waypost-remove
  // route for an asked path whose plan-time askedNonDefault was true —
  // recheck() never changes that field, so this only ever re-states the
  // same refusal the plan already made, never a route that reached here.
  if (item.source === "asked" && item.askedNonDefault === true && route && route.kind === "waypost-remove") {
    return { ok: false, reason: "an asked (non-default) cache path is removed only through its own clean_argv" };
  }
  return { ok: true };
}

// ─── the routes themselves — the only removal calls in this whole tree ──

// `git clean -X` over a 35 GB target/, or `go clean -modcache` over a large
// module cache, can run for minutes — long enough that a short timeout would
// kill the process mid-removal and leave a half-deleted tree, reported as a
// clean "failed" with nothing actually verified. 30 minutes, the same order
// of magnitude `waypost run --heavy`'s own long jobs already run under,
// while still holding this command's own machine-wide slot the whole time.
const REMOVE_TIMEOUT_MS = 30 * 60 * 1000;

function removeItem(item, route, ctx, mods) {
  if (route.kind === "waypost-remove") {
    rmSync(item.path, { recursive: true });
    return;
  }
  if (route.kind === "git-clean-x") {
    const rel = relative(ctx.root, item.path);
    const r = spawnSync("git", ["--literal-pathspecs", "-C", ctx.root, "clean", "-X", "-d", "-f", "--", rel],
      { encoding: "utf8", timeout: REMOVE_TIMEOUT_MS });
    if (r.error) throw r.error;
    if (r.status !== 0) throw new Error(`git clean exited ${r.status}: ${(r.stderr || "").trim().slice(0, 300)}`);
    return;
  }
  if (route.kind === "tool-clean-argv") {
    const bin = mods.discovery.findOnPath(route.argv[0], { platform: ctx.platform, env: process.env });
    if (!bin) throw new Error(`${route.argv[0]} not found on PATH`);
    if (ctx.platform === "win32" && mods.toolchains.BATCH_SHIM_RE.test(bin)) {
      throw new Error(`${route.argv[0]} is a .cmd/.bat shim — refused, the same as asking it`);
    }
    // Project: the manifest directory (the item's own parent) — a tool's
    // project-clean command runs the way it would from a checkout. Machine:
    // home, the same cwd asking it already uses.
    const cwd = item.scope === "project" ? dirname(item.path) : ctx.home;
    const r = spawnSync(bin, route.argv.slice(1), { shell: false, stdio: ["ignore", "pipe", "pipe"], cwd, timeout: REMOVE_TIMEOUT_MS, encoding: "utf8" });
    if (r.error) throw r.error;
    if (r.status !== 0) throw new Error(`${route.argv[0]} exited ${r.status}: ${(r.stderr || "").trim().slice(0, 300)}`);
    return;
  }
  throw new Error("no route");
}

// What a partial git-clean-x left behind, best effort — never blocks the
// result itself if either read fails.
function describeKept(item, ctx, mods) {
  const parts = [];
  let inspected = null;
  try { inspected = mods.sizes.inspectDir(item.path, {}); } catch { /* best effort */ }
  if (inspected && inspected.nested_git) parts.push("a nested repository");
  try {
    const rel = relative(ctx.root, item.path);
    const gf = mods.sizes.gitFacts(ctx.root, [rel]);
    if (gf.tracked.has(rel)) parts.push("tracked file(s)");
  } catch { /* best effort */ }
  return parts.length ? parts.join(" and ") : "some content";
}

// lstat ENOENT is the only "removed" verdict; anything else that still
// exists but reads smaller than it did right before the route ran is
// "partial" — a real success for git-clean-x, which by design never removes
// a tracked file or a nested repository even when this module's own
// pre-checks somehow missed one. Anything else is "failed".
function verifyRemoval(item, ctx, mods, beforeBytes) {
  let st;
  try { st = lstatSync(item.path); }
  catch (e) {
    if (e.code === "ENOENT") return { result: "removed", freed_bytes: Number.isFinite(beforeBytes) ? beforeBytes : 0 };
    return { result: "failed", freed_bytes: 0, reason: `could not verify: ${e.message}` };
  }
  let after = null;
  try { after = mods.sizes.inspectDir(item.path, { metadata: ctx.metadataNames }); } catch { /* leaves after null */ }
  if (after && after.exists && Number.isFinite(after.bytes) && Number.isFinite(beforeBytes) && after.bytes < beforeBytes) {
    return { result: "partial", freed_bytes: beforeBytes - after.bytes, kept: describeKept(item, ctx, mods) };
  }
  return { result: "failed", freed_bytes: 0, reason: "still there after the route ran" };
}

// ─── consent, the log, and the apply loop itself ───────────────────────

const APFS_FREE_SPACE_NOTE = "free space is read with fs.statfsSync; bavail excludes APFS purgeable space, so freed space can read smaller than what was actually removed";

// Rotated at 1 MiB, keeping one previous file (the amended machine-wide-
// limit ADR): checked before every append, so the log itself never grows
// without bound on a machine where `run --heavy` logs one line per job
// indefinitely. renameSync onto an existing `.1` replaces it on every OS
// Node supports this on (POSIX rename(2) always replaces; Node's own
// implementation asks Windows to do the same) — no separate unlink needed.
const CLEAN_LOG_ROTATE_BYTES = 1024 * 1024;

function appendCleanLog(host, line) {
  const dir = ensureMachineStateDir();
  const file = join(dir, `cleanup.${host}.jsonl`);
  try {
    if (statSync(file).size >= CLEAN_LOG_ROTATE_BYTES) renameSync(file, `${file}.1`);
  } catch { /* no file yet — nothing to rotate */ }
  appendFileSync(file, line + "\n", "utf8");
}

function baseLogItem(item) {
  return { id: item.id, scope: item.scope, path: item.path, bytes: item.bytes, class: item.class, route: item.route };
}

function refusedLogItem(r) {
  return { id: r.id, scope: r.scope, path: r.path, bytes: r.bytes, class: r.class, route: r.route, result: "refused", reason: r.reason, freed_bytes: 0, kept: null };
}

// ─── the detached deleter (the amended machine-wide-limit ADR, Decision 4) ──
//
// Nothing here is a removal call outside this dispatch: renameSync moves an
// item aside (a rename, not a delete), and the actual removal runs in a
// SEPARATE, detached process this file spawns and forgets about — so the
// caller (the automatic path at the end of `run --heavy`, commit C; or a
// `waypost clean` adopting a leftover) returns without waiting for a
// multi-gigabyte tree to actually vanish from disk. `waypost-removing/`
// sits directly in the git common dir, outside ADR-0010's own
// `waypost/<vault>/` coordination tree, so a coordination-tree sweep and a
// leftover-deleter sweep can never collide.
const REMOVING_NAME_RE = /^[0-9a-z]+-\d+-[0-9a-f]{6}$/;

function randomHex6() {
  return Math.floor(Math.random() * 0x1000000).toString(16).padStart(6, "0");
}

// One item, renamed aside right before its own removal. The marker (who is
// about to delete it) is written FIRST, the rename itself second — so a
// reader only ever sees waypost-removing/ hold a directory with no marker
// beside it as the result of a crash between these two writes, which
// leftoversOf() below always treats as adoptable (no marker means nobody's).
function renameForRemoval(item, removingDir, marker) {
  mkdirSync(removingDir, { recursive: true });
  const name = `${Date.now().toString(36)}-${process.pid}-${randomHex6()}`;
  const markerPath = join(removingDir, `${name}.json`);
  const dest = join(removingDir, name);
  try {
    writeFileAtomic(markerPath, JSON.stringify({ ...marker, from: item.path, id: item.id }, null, 2) + "\n");
  } catch (e) {
    return { ok: false, reason: `could not write the removal marker: ${e.message}` };
  }
  try {
    renameSync(item.path, dest);
  } catch (e) {
    try { unlinkSync(markerPath); } catch {}
    if (e.code === "EXDEV") return { ok: false, reason: "another filesystem — the git common dir and this item are not on the same device" };
    if (e.code === "EPERM" || e.code === "EBUSY") return { ok: false, reason: "a file inside is open" };
    return { ok: false, reason: e.message };
  }
  return { ok: true, name, dest, markerPath };
}

// Spawns the detached, low-priority deleter for a batch of already-renamed
// entries sharing one waypost-removing/ directory, then rewrites each
// entry's own marker's `proc` to name the deleter — NOT the whole marker as
// a fresh selfMarker() would (started/ticks read here would describe the
// process that is about to exit, this one, a moment after spawning; nulled
// rather than left wrong, since a wrong-but-present started/ticks pair
// would make a live deleter read as a reused pid — processGone()'s own safe
// fallback for "no timing recorded" is to trust the pid alone). The
// deleter's own first action (handleInternalDelete below) writes the
// complete, authoritative marker from ITS OWN selfMarker() once it is
// actually running and can read its own process-table entry; this rewrite
// only guarantees the pid is right even if it is killed before that.
function spawnDeleter(removingDir, names, marker) {
  const child = spawn(process.execPath, [join(ROOT, "bin", "waypost"), "__waypost-delete", removingDir, ...names],
    { detached: true, stdio: "ignore", windowsHide: true });
  child.unref();
  for (const name of names) {
    const markerPath = join(removingDir, `${name}.json`);
    try {
      const rec = JSON.parse(readFileSync(markerPath, "utf8"));
      writeFileAtomic(markerPath, JSON.stringify({
        ...rec, proc: { pid: child.pid, started: null, ticks: null, comm: marker.proc.comm },
      }, null, 2) + "\n");
    } catch { /* best effort — the deleter still runs; its own rewrite corrects this */ }
  }
  return child.pid;
}

// Every waypost-removing/ entry an interrupted run or a dead deleter left
// behind — from this host and any other, since worktrees (and hosts sharing
// a checkout) share one common dir (ADR-0010). One process table and one
// boot-identity/authority read for the whole pass, not one per entry.
// Never removes anything itself — the caller hands adoptable entries to a
// FRESH deleter through the same rename-and-detach path every other
// removal already uses (here, that rename already happened; only the
// deleter is new).
function leftoversOf(common, capacity, presence) {
  const dir = join(common, REMOVING_DIR);
  let names;
  try { names = readdirSync(dir); } catch { return { adopt: [], leave: [] }; }
  const table = process.platform === "win32" ? null : presence.processTable();
  const bootNow = capacity.bootIdentity();
  const authority = capacity.authorityOnce();
  const here = hostname().split(".")[0];
  const isAlive = (marker) => capacity.slotLive(marker, { table, bootNow, authority });
  const entries = new Set(names.filter((n) => !n.endsWith(".json")));
  const adopt = [];
  const leave = [];

  for (const n of names) {
    if (!n.endsWith(".json")) continue;
    const base = n.slice(0, -5);
    const markerPath = join(dir, n);
    const entryPath = join(dir, base);
    let marker = null;
    try { marker = JSON.parse(readFileSync(markerPath, "utf8")); } catch { marker = null; }
    const hasEntry = entries.has(base);

    if (!hasEntry) {
      // A marker with no directory beside it: the entry is already gone
      // (the deleter finished removing it and only failed on the marker's
      // own unlink) — always adoptable once its owner is dead, since
      // nothing is left for a live deleter to still be working on.
      const alive = marker && marker.proc && marker.host === here && isAlive(marker);
      if (alive) leave.push({ name: base, entry: null, markerPath, marker });
      else adopt.push({ name: base, entry: null, markerPath, marker });
      continue;
    }
    if (!marker) {
      // No marker at all — renameForRemoval always writes it BEFORE the
      // rename, so a crash between those two writes is the only way to
      // reach this, and it is always adoptable.
      adopt.push({ name: base, entry: entryPath, markerPath: null, marker: null });
      continue;
    }
    if (marker.host !== here) { leave.push({ name: base, entry: entryPath, markerPath, marker }); continue; }
    if (isAlive(marker)) leave.push({ name: base, entry: entryPath, markerPath, marker });
    else adopt.push({ name: base, entry: entryPath, markerPath, marker });
  }
  // An entry with no marker file beside it at all (a deleter that failed
  // partway once unlinked it): adoptable — purgeLeftovers re-marks it, or
  // leaves and counts it when its name is not one renameForRemoval mints.
  const markers = new Set(names.filter((n) => n.endsWith(".json")).map((n) => n.slice(0, -5)));
  for (const base of entries) {
    if (!markers.has(base)) adopt.push({ name: base, entry: join(dir, base), markerPath: null, marker: null });
  }
  return { adopt, leave };
}

// Right after claiming the slot, for both the plan and --apply (the ADR:
// "Any cleanup, manual or automatic, first purges what an interrupted run
// left"). `--limit` never calls this. A marker whose own entry is already
// gone is simply unlinked here — there is nothing left to hand a new
// deleter; every adoptable entry that still holds real content is handed
// to one fresh deleter together.
function purgeLeftovers(where, { capacity, presence }) {
  if (!where || !where.common) return { handed_off: [], left: 0 };
  const { adopt, leave } = leftoversOf(where.common, capacity, presence);
  if (!adopt.length) return { handed_off: [], left: leave.length };
  const dir = join(where.common, REMOVING_DIR);
  for (const a of adopt) {
    if (!a.entry && a.markerPath) { try { unlinkSync(a.markerPath); } catch {} }
  }
  // The deleter only touches a name of the shape renameForRemoval mints that
  // carries a marker: an entry that lost its marker gets a fresh one here
  // (adopting it), and a name of any other shape is left and counted.
  const marker = selfMarker(capacity, presence);
  const handed = [];
  let left = leave.length;
  for (const a of adopt.filter((x) => x.entry)) {
    if (!REMOVING_NAME_RE.test(a.name)) { left++; continue; }
    if (!a.marker) {
      try { writeFileAtomic(join(dir, `${a.name}.json`), JSON.stringify({ ...marker, adopted: true }, null, 2) + "\n"); }
      catch { left++; continue; }
    }
    handed.push(a.name);
  }
  if (handed.length) spawnDeleter(dir, handed, marker);
  return { handed_off: handed, left };
}

// ─── the internal deleter command itself ────────────────────────────────
//
// `waypost __waypost-delete <dir> <name…>` — never invoked by a person,
// only by spawnDeleter above, detached. Dispatched first thing in main(),
// before ANY of the session/harness/heartbeat machinery every other
// command goes through: this is not a session, and none of that applies to
// a process nobody is watching.
async function handleInternalDelete(argv) {
  const [dir, ...names] = argv;
  if (!dir || basename(dir) !== REMOVING_DIR) { process.exitCode = 1; return; }
  let st;
  try { st = lstatSync(dir); } catch { process.exitCode = 1; return; }
  if (!st.isDirectory() || st.isSymbolicLink()) { process.exitCode = 1; return; }
  // Strictly validated: only a name matching the exact shape
  // renameForRemoval mints, AND carrying its own marker, is ever touched —
  // this command's own argv is not something a person is expected to type,
  // so it is held to the same standard as any other untrusted input.
  const valid = names.filter((n) => REMOVING_NAME_RE.test(n) && existsSync(join(dir, `${n}.json`)));
  if (!valid.length) return;

  try { setPriority(osConstants.priority.PRIORITY_LOW); }
  catch { /* best effort — a restricted sandbox must not block the deletion */ }

  let marker = null;
  try {
    const capacity = await import(SCRIPT_URL("capacity"));
    const presence = await import(SCRIPT_URL("presence"));
    marker = selfMarker(capacity, presence);
  } catch { /* best effort — deletion proceeds either way */ }

  for (const name of valid) {
    const entry = join(dir, name);
    const markerPath = join(dir, `${name}.json`);
    if (marker) {
      try {
        const rec = JSON.parse(readFileSync(markerPath, "utf8"));
        writeFileAtomic(markerPath, JSON.stringify({ ...rec, ...marker }, null, 2) + "\n");
      } catch { /* best effort — deletion proceeds either way */ }
    }
    try { rmSync(entry, { recursive: true, force: true, maxRetries: 3 }); }
    catch { /* best effort — a leftover here is swept by the next waypost clean */ }
    // The marker goes only with its entry: a partly removed entry keeps it,
    // so the next `waypost clean` can adopt it once this deleter is gone.
    if (!existsSync(entry)) { try { unlinkSync(markerPath); } catch {} }
  }
}

// ─── waypost clean --limit (the amended machine-wide-limit ADR, Decision 2) ──

// Names the SPECIFIC evidence a refusal was based on — an ancestor process
// or an environment marker — not just which harness was found, so a person
// staring at a refusal for a harness they do not think is running has
// something to actually check. The basename/word normalisation mirrors
// gateCheck's own (scripts/agents.mjs) closely enough to usually find the
// exact matching ancestor; when it cannot (a registry `process` name that
// differs from the harness id, say), it still names the harness itself.
function gateEvidenceOf(gateResult) {
  if (!gateResult) return null;
  if (gateResult.via === "process") {
    const norm = (c) => String(c || "").toLowerCase().split(/[\\/]/).pop().split(/[^a-z0-9]+/)[0];
    const hit = gateResult.ancestors.find((a) => norm(a.comm) === gateResult.harness || norm(a.argv0) === gateResult.harness);
    return hit ? `an ancestor process "${gateResult.harness}" (pid ${hit.pid})` : `an ancestor process (${gateResult.harness})`;
  }
  if (gateResult.via === "env" && gateResult.markers.length) return `the environment variable ${gateResult.markers[0].var}`;
  return gateResult.harness ? `a harness (${gateResult.harness})` : null;
}

function gateRefusalMessage(decision, gateResult, gateError) {
  const evidence = gateEvidenceOf(gateResult);
  if (evidence) {
    return `${decision.reason} (${evidence}) — set it from your own terminal, or run `
      + "\`waypost clean --limit off\` (or a looser value), which works from anywhere";
  }
  if (gateError) return `${decision.reason} (the harness check itself failed: ${gateError})`;
  return decision.reason;
}

// A read-only look at what the NEW limit would need to free, right now,
// without renaming anything — printed to stderr before the [y/N] itself, so
// the person answering it sees exactly what they are agreeing to.
function printLimitPreview(parsed, mods, now) {
  const { cleanup } = mods;
  const root = slotWhere(projectRoot()).root;
  const home = (() => { try { return realpathSync(homedir()); } catch { return homedir(); } })();
  if (!root || cleanup.refusePath(root, { home })) {
    process.stderr.write("(no project here — nothing to preview)\n");
    return;
  }
  let ctx, classified;
  try {
    ctx = gatherCleanContext(mods);
    classified = planFromContext(ctx, cleanup, now);
  } catch (e) {
    process.stderr.write(`(could not build a preview: ${e.message})\n`);
    return;
  }
  let shortfall = 0;
  let dev = null;
  if (parsed.kind === "free") {
    try {
      const s = statfsSync(root);
      shortfall = cleanup.shortfallOf({ size: s.blocks * s.bsize, avail: s.bavail * s.bsize }, parsed.percent);
    } catch { /* best effort */ }
    try { dev = lstatSync(root).dev; } catch { /* best effort */ }
  }
  const { counted, need, eligible } = cleanup.limitNeed(classified, parsed, now, { shortfall, dev });
  process.stderr.write(`This project's build output counts ${(counted / GB).toFixed(2)} GB towards the limit.\n`);
  if (need <= 0) {
    process.stderr.write("Nothing would need to be removed right now.\n");
    return;
  }
  process.stderr.write(`${(need / GB).toFixed(2)} GB would need to be freed. Oldest first, right now that is:\n`);
  let running = 0;
  for (const it of eligible) {
    if (running >= need) break;
    const days = Math.floor((now - it.newest_ms) / (24 * 60 * 60 * 1000));
    process.stderr.write(`  ${(it.bytes / GB).toFixed(2)} GB  idle ${days}d  ${it.rel || tildeHome(it.path)}\n`);
    running += it.bytes || 0;
  }
}

async function handleCleanLimit(rawValue, mods, json, now) {
  const { cleanup, capacity, presence } = mods;
  const host = presence.hostSlug();

  if (rawValue == null) {
    const setting = readCleanupSetting({ host });
    const outcome = readLastAutoCleanup({ host });
    if (json) {
      process.stdout.write(JSON.stringify({
        setting: setting || null, last_auto: outcome,
        choices: { gb: "<N> (e.g. 5, 10, 20, 50) — gigabytes per project", free: "free:<P>% (P 5-50) — keep at least that much of the disk free", off: "off — no automatic cleanup" },
      }, null, 2) + "\n");
      return;
    }
    process.stdout.write(`cleanup limit: ${cleanup.formatLimit(setting ? setting.limit : null)}`
      + (setting ? ` (set ${setting.set_at})\n` : "\n"));
    process.stdout.write(`${cleanup.formatOutcome(outcome)}\n`);
    process.stdout.write("choices: 5 | 10 | 20 | 50 | <N> (GB per project) | free:<P>% (5-50) | off\n");
    return;
  }

  const parsed = cleanup.parseLimit(rawValue);
  if (!parsed) fail(`clean --limit: invalid value "${rawValue}" — <N> (GB per project), free:<P>% (5-50), or off`);

  const currentSetting = readCleanupSetting({ host });
  const currentLimit = currentSetting ? currentSetting.limit : null;
  const { change, gated } = cleanup.limitChange(currentLimit, parsed);

  if (change === "same") {
    if (json) process.stdout.write(JSON.stringify({ change: "same", limit: parsed }, null, 2) + "\n");
    else process.stdout.write("unchanged\n");
    return;
  }

  let agents;
  try { agents = await import(SCRIPT_URL("agents")); } catch (e) { fail(`clean --limit: ${e.message}`); }

  // Always run, gated or not: an off/loosen change is never refused by it,
  // but its own view is still recorded in the setting (the ADR: "every
  // setting records how it was made"). Pinned to the executable's OWN tree
  // (ROOT), never WAYPOST_HOME — an agent pointing that elsewhere must not
  // be able to steer which harness registry the gate itself reads.
  let gateResult = null;
  let gateError = null;
  try {
    gateResult = agents.gateCheck({
      env: process.env,
      dirs: [join(ROOT, "harnesses"), join(projectRoot(), ".waypost", "harnesses")],
    });
  } catch (e) { gateError = e.message; }

  const decision = cleanup.limitDecision({
    gated, harness: gateResult ? gateResult.harness : null,
    checkError: Boolean(gateError), isTTY: Boolean(process.stdin.isTTY),
  });

  if (decision.ok === false) {
    const message = gateRefusalMessage(decision, gateResult, gateError);
    if (json) process.stdout.write(JSON.stringify({ ok: false, message }, null, 2) + "\n");
    else process.stderr.write(`waypost clean --limit: ${message}\n`);
    process.exitCode = 1;
    return;
  }

  if (decision.method === "prompt") {
    printLimitPreview(parsed, mods, now);
    const answered = await askYesNo(`Set the cleanup limit to ${cleanup.formatLimit(parsed)}? [y/N] `, { timeoutMs: 60000 });
    if (!answered) {
      process.stderr.write("waypost clean --limit: not set\n");
      process.exitCode = 1;
      return;
    }
  }

  const gateInfo = {
    required: gated,
    checked: gateResult ? (gateResult.process_table ? "process-table+env-markers" : "env-markers-only") : "env-markers-only",
    harness: gateResult ? gateResult.harness : null,
    via: gateResult ? gateResult.via : null,
    ancestors: gateResult ? gateResult.ancestors : [],
    markers: gateResult ? gateResult.markers : [],
    tty: Boolean(process.stdin.isTTY),
    answer: decision.method === "prompt" ? true : null,
  };
  const setAt = new Date(now).toISOString();
  const settingRec = {
    v: 1, host, limit: parsed, set_at: setAt, change, previous: currentLimit, written_by: LIMIT_WRITER,
    gate: gateInfo, by: { session: process.env.WAYPOST_SESSION_ID || null },
  };
  try {
    ensureMachineStateDir();
    writeFileAtomic(join(machineStateDir(), `cleanup-limit.${host}.json`), JSON.stringify(settingRec, null, 2) + "\n");
  } catch (e) { fail(`clean --limit: could not write the setting: ${e.message}`); }

  const line = cleanup.logLine({
    kind: "limit", at: setAt, host, session: settingRec.by.session,
    from: currentLimit, to: parsed, change, gate: gateInfo,
  });
  let logError = null;
  try { appendCleanLog(host, line); } catch (e) { logError = e.message; }

  if (json) {
    process.stdout.write(JSON.stringify({ ok: true, ...settingRec, ...(logError ? { log_error: logError } : {}) }, null, 2) + "\n");
  } else {
    process.stdout.write(`cleanup limit set to ${cleanup.formatLimit(parsed)} (${change})\n`);
    if (logError) process.stdout.write(`  log not written: ${logError}\n`);
  }
  if (logError) process.exitCode = 1;
}

function printApplyPreview(items) {
  const total = items.reduce((s, it) => s + (it.bytes || 0), 0);
  process.stderr.write(`About to remove ${items.length} item(s), ${(total / GB).toFixed(2)} GB total:\n`);
  for (const it of items) process.stderr.write(`  ${it.id}  ${(it.bytes / GB).toFixed(2)} GB  ${it.path}\n`);
}

function groupByDev(ordered) {
  const groups = new Map();
  ordered.forEach((item, idx) => {
    const key = item.dev ?? "unknown";
    if (!groups.has(key)) groups.set(key, { dev: item.dev ?? null, path: dirname(item.path), firstIndex: idx, lastIndex: idx });
    else groups.get(key).lastIndex = idx;
  });
  return groups;
}

// `source` and `prebuilt` let a caller other than `clean` itself (`setup`'s
// own audit step) reuse this whole removal path: `source` tags the log line
// ("setup" instead of "clean"), and `prebuilt` — an already-built
// `{ ctx, classified }`, from the SAME gatherCleanContext/planFromContext
// this function would otherwise call — skips a second, redundant scan when
// the caller already built one (setup's own report needs it anyway).
async function applyClean(sel, consent, mods, now, { source = "clean", prebuilt = null } = {}) {
  const { cleanup, presence } = mods;
  const root = projectRoot();
  const host = presence.hostSlug();
  const selection = selectionDescriptorOf(sel);

  const logAndReturn = (yesField, items, exitCode) => {
    const line = cleanup.logLine({
      at: new Date(now).toISOString(), host, session: process.env.WAYPOST_SESSION_ID || null,
      harness: process.env.WAYPOST_HARNESS || null, source, root,
      clock: lastCleanNowHonored ? process.env.WAYPOST_CLEAN_NOW : null,
      yes: yesField, selection, items, filesystems: [], exit: exitCode,
    });
    // Same reasoning as the final log write below: nothing was removed here
    // either way (a decline), but a log-write failure must still surface
    // rather than silently claim the decline was recorded when it was not.
    let logError = null;
    try { appendCleanLog(host, line); } catch (e) { logError = e.message; }
    return { exitCode: logError ? 1 : exitCode, logError };
  };

  // Build the plan fresh, right now, unless the caller already did: "should"
  // re-plans against the current state; an id is looked up against this
  // same fresh plan, never a stale earlier one.
  const ctx = prebuilt ? prebuilt.ctx : gatherCleanContext(mods);
  const classified = prebuilt ? prebuilt.classified : planFromContext(ctx, cleanup, now);
  const { toApply, refused } = resolveApplySelection(classified, sel);

  if (consent.method === "prompt" && toApply.length) {
    printApplyPreview(toApply);
    const answered = await askYesNo(`Remove ${toApply.length} item(s)? [y/N] `, { timeoutMs: 60000 });
    if (!answered) {
      const items = [...refused.map(refusedLogItem), ...toApply.map((it) => ({ ...baseLogItem(it), result: "declined", reason: "not confirmed", freed_bytes: 0, kept: null }))];
      const { exitCode, logError } = logAndReturn({ by: null, declined: true }, items, 1);
      return { exitCode, declined: true, message: "not confirmed — nothing removed", ...(logError ? { log_error: logError } : {}) };
    }
  }

  // ── remove, ancestors first, filesystem free space measured per device ──
  const ordered = orderForRemoval(toApply);
  const devGroups = groupByDev(ordered);
  const fsStats = new Map();
  const removedRoots = [];
  const results = [];

  for (let i = 0; i < ordered.length; i++) {
    const item = ordered[i];
    const groupKey = item.dev ?? "unknown";
    const group = devGroups.get(groupKey);
    if (i === group.firstIndex) {
      try {
        const s = statfsSync(group.path);
        fsStats.set(groupKey, { dev: group.dev, path: group.path, free_before: s.bavail * s.bsize, free_after: null });
      } catch { /* best effort — this filesystem's free space just is not reported */ }
    }

    const ancestor = removedRoots.find((r) => isDescendantOf(item.path, r.path));
    if (ancestor) {
      results.push({ ...baseLogItem(item), result: "removed", reason: `removed with ${ancestor.id}`, freed_bytes: 0, kept: null });
    } else {
      try {
        const rc = recheckItem(item, ctx, mods, now);
        const stillEligible = sel.mode === "should" ? rc.class === "should" : rc.class !== "keep";
        if (rc.changed || !stillEligible || !rc.route) {
          results.push({ ...baseLogItem(item), result: "skipped", reason: rc.reason, freed_bytes: 0, kept: null });
        } else {
          const safe = machinePathStillSafe(item, ctx, mods, rc.route);
          if (!safe.ok) {
            results.push({ ...baseLogItem(item), result: "skipped", reason: safe.reason, freed_bytes: 0, kept: null });
          } else {
            const beforeBytes = Number.isFinite(rc.fresh.bytes) ? rc.fresh.bytes : item.bytes;
            try {
              removeItem(item, rc.route, ctx, mods);
              const v = verifyRemoval(item, ctx, mods, beforeBytes);
              results.push({ ...baseLogItem(item), result: v.result, reason: v.reason || null, freed_bytes: v.freed_bytes, kept: v.kept || null });
              if (v.result === "removed") removedRoots.push({ path: item.path, id: item.id });
            } catch (e) {
              // A route that threw (a timeout on a huge tree, in
              // particular) may still have removed real content before it
              // did — re-measure best effort so a killed-mid-removal
              // `git clean -X` is reported with the bytes it actually
              // freed, not a flat 0 that hides gigabytes of real progress.
              let freedBytes = 0;
              let reason = e.message;
              try {
                const after = mods.sizes.inspectDir(item.path, { metadata: ctx.metadataNames });
                if (!after || after.exists === false) {
                  freedBytes = Number.isFinite(beforeBytes) ? beforeBytes : 0;
                } else if (after.exists && Number.isFinite(after.bytes) && Number.isFinite(beforeBytes) && after.bytes < beforeBytes) {
                  freedBytes = beforeBytes - after.bytes;
                  reason = `${e.message} (partial — some content was removed before this failed)`;
                }
              } catch { /* best effort — report the error alone */ }
              results.push({ ...baseLogItem(item), result: "failed", reason, freed_bytes: freedBytes, kept: null });
            }
          }
        }
      } catch (e) {
        results.push({ ...baseLogItem(item), result: "failed", reason: e.message, freed_bytes: 0, kept: null });
      }
    }

    if (i === group.lastIndex) {
      const rec = fsStats.get(groupKey);
      if (rec) { try { const s = statfsSync(group.path); rec.free_after = s.bavail * s.bsize; } catch { /* best effort */ } }
    }
  }

  const filesystems = [...fsStats.values()].map((r) => ({
    dev: r.dev, path: r.path, free_before: r.free_before, free_after: r.free_after,
    freed: (r.free_after != null && r.free_before != null) ? r.free_after - r.free_before : null,
  }));

  const allItems = [...refused.map(refusedLogItem), ...results];
  const exitCode = (refused.length === 0 && results.every((r) => r.result === "removed" || r.result === "partial")) ? 0 : 1;
  const yesField = consent.method === "flag" ? { by: "flags", reason: consent.reason } : { by: "terminal" };

  const line = cleanup.logLine({
    at: new Date(now).toISOString(), host, session: process.env.WAYPOST_SESSION_ID || null,
    harness: process.env.WAYPOST_HARNESS || null, source, root,
    clock: lastCleanNowHonored ? process.env.WAYPOST_CLEAN_NOW : null,
    yes: yesField, selection, items: allItems, filesystems, exit: exitCode,
  });
  // The report above is real work already done (removals, verified,
  // measured) — a failure writing ITS log line (ENOSPC, a read-only state
  // dir) must never throw this away. Caught here, surfaced as its own
  // field, and forced non-zero: the caller still sees exactly what
  // happened to every item, plus the one thing that did not get recorded.
  let logError = null;
  try { appendCleanLog(host, line); } catch (e) { logError = e.message; }

  return {
    exitCode: logError ? 1 : exitCode, host, root, selection, items: allItems, filesystems,
    apfs_note: APFS_FREE_SPACE_NOTE, ...(logError ? { log_error: logError } : {}),
  };
}

function printApplyResult(result) {
  // A consent refusal (no valid --yes --reason, no eligible terminal) is
  // handled directly in handleClean, before this is ever reached — only a
  // declined interactive prompt (the plan was already built to show it)
  // takes this early return here.
  if (result.declined) {
    process.stderr.write(`waypost clean --apply: ${result.message}\n`);
    if (result.log_error) process.stderr.write(`  log not written: ${result.log_error}\n`);
    return;
  }
  if (result.leftovers && result.leftovers.handed_off.length) {
    process.stdout.write(`(${result.leftovers.handed_off.length} leftover item(s) from an interrupted run handed to the deleter)\n`);
  }
  for (const it of result.items) {
    const where = it.path ? tildeHome(it.path) : (it.id || "?");
    process.stdout.write(`  ${it.id || "?"}  ${it.result}  ${where}\n`);
    if (it.reason) process.stdout.write(`    ${it.reason}\n`);
    if (it.kept) process.stdout.write(`    kept: ${it.kept}\n`);
  }
  for (const fsEntry of result.filesystems) {
    if (fsEntry.freed == null) continue;
    process.stdout.write(`  ${tildeHome(fsEntry.path)}: ${(fsEntry.freed / GB).toFixed(2)} GB freed\n`);
  }
  if (result.filesystems.length) process.stdout.write(`  (${result.apfs_note})\n`);
  if (result.log_error) process.stdout.write(`  log not written: ${result.log_error}\n`);
  process.stdout.write(result.exitCode === 0 ? "done\n" : "done, with issues — see above\n");
}

async function handleClean(args) {
  const json = flag(args, "--json");
  const applySel = parseApplySelection(args);
  if (applySel && applySel.mode === "empty") { fail("clean --apply: needs an id, a list of ids, or should"); return; }
  if (applySel && applySel.mode === "can") { fail("clean --apply can: refused — can items are removed only by id"); return; }
  const limitFlag = limitFlagValue(args);
  if (limitFlag.present && applySel) { fail("clean --limit: refused together with --apply"); return; }

  let cleanup, sizes, toolchains, capacity, presence, discovery;
  try {
    cleanup = await import(SCRIPT_URL("cleanup"));
    sizes = await import(SCRIPT_URL("sizes"));
    toolchains = await import(SCRIPT_URL("toolchains"));
    capacity = await import(SCRIPT_URL("capacity"));
    presence = await import(SCRIPT_URL("presence"));
    discovery = await import(SCRIPT_URL("discovery"));
  } catch (e) { fail(`clean: ${e.message}`); }

  const now = cleanNow();

  // waypost clean --limit — the machine-wide setting (the amended ADR): no
  // slot needed, decided entirely before the consent/slot machinery below,
  // which is --apply's own.
  if (limitFlag.present) {
    await handleCleanLimit(limitFlag.value, { cleanup, sizes, toolchains, capacity, presence, discovery }, json, now);
    return;
  }

  // --apply's consent is decided before the machine-wide slot is ever
  // claimed: a harness detected, or no terminal and no --yes --reason, must
  // refuse the SAME way whether or not the machine happens to be busy with
  // something else entirely — claiming a slot first would make that refusal
  // depend on machine load, and waste a slot on a request that was always
  // going to be refused.
  let consentDecision = null;
  if (applySel) {
    const yes = flag(args, "--yes");
    const reasonFlag = opt(args, "--reason");
    const isTTY = Boolean(process.stdin.isTTY);
    const harnessDetected = await isHarnessDetected();
    consentDecision = cleanup.consent({ yes, reason: reasonFlag, isTTY, harnessDetected });
    if (consentDecision.method === "refused") {
      const host = presence.hostSlug();
      const root = projectRoot();
      const line = cleanup.logLine({
        at: new Date(now).toISOString(), host, session: process.env.WAYPOST_SESSION_ID || null,
        harness: process.env.WAYPOST_HARNESS || null, source: "clean", root,
        clock: lastCleanNowHonored ? process.env.WAYPOST_CLEAN_NOW : null,
        yes: { by: null, declined: false }, selection: selectionDescriptorOf(applySel), items: [], filesystems: [], exit: 1,
      });
      // Nothing was ever going to be removed on this path either way (a
      // refusal, exit 1 regardless) — but a log-write failure (ENOSPC, a
      // read-only state dir) must still be reported, not swallowed.
      let logError = null;
      try { appendCleanLog(host, line); } catch (e) { logError = e.message; }
      const message = `${consentDecision.reason} — pass --yes --reason "<who agreed, when>" or run \`waypost prompt cleanup\``;
      if (json) {
        process.stdout.write(JSON.stringify({ exitCode: 1, refusedEarly: true, message, ...(logError ? { log_error: logError } : {}) }, null, 2) + "\n");
      } else {
        process.stderr.write(`waypost clean --apply: ${message}\n`);
        if (logError) process.stderr.write(`  log not written: ${logError}\n`);
      }
      process.exitCode = 1;
      return;
    }
  }

  // Same rule as `size --global` (WP-18 Decision 4): a machine-wide scan
  // holds the machine-wide slot, same refusal (exit 75), for the plan AND
  // for --apply. No fail() between the claim and the finally below, so the
  // slot is always released.
  const dir = slotsDir(presence);
  mkdirSync(dir, { recursive: true });
  const where = slotWhere(projectRoot());
  const claim = await claimSlot(dir, ["waypost", "clean", ...(applySel ? ["--apply"] : []), ...(json ? ["--json"] : [])], capacity, presence, where);
  if (!claim.ok) {
    process.stderr.write(`waypost clean: refused — ${claim.reason}\n  retry: waypost clean\n`);
    process.exitCode = EX_TEMPFAIL;
    return;
  }
  recordAuthority(claim.file, capacity);

  // Any cleanup, manual or automatic, first purges what an interrupted run
  // left in waypost-removing/ (the amended ADR, Decision 4) — right after
  // the claim, whatever the conditions below decide about this run's own
  // plan or apply.
  let purge = { handed_off: [], left: 0 };
  try { purge = purgeLeftovers(where, { capacity, presence }); } catch { /* best effort — never blocks the plan/apply below */ }

  const mods = { cleanup, sizes, toolchains, presence, discovery };
  let result, error, applyResult = false;
  try {
    if (!applySel) {
      const ctx = gatherCleanContext(mods);
      const { limit, shortfall, dev } = activeLimitFor(ctx.root, cleanup, presence);
      const classified = planFromContext(ctx, cleanup, now, { limit, shortfall, dev });
      result = formatPlan(classified, ctx, now);
    } else {
      applyResult = true;
      result = await applyClean(applySel, consentDecision, mods, now);
    }
  } catch (e) {
    error = e;
  } finally {
    claim.release();
  }
  if (error) fail(`clean: ${error.message}`);

  if (purge.handed_off.length) {
    const host = presence.hostSlug();
    const line = cleanup.logLine({
      kind: "purge", at: new Date(now).toISOString(), host, session: process.env.WAYPOST_SESSION_ID || null,
      root: where.root, handed_off: purge.handed_off.length,
    });
    try { appendCleanLog(host, line); } catch { /* best effort — the purge itself already ran */ }
  }
  if (result && typeof result === "object") result.leftovers = { handed_off: purge.handed_off, left: purge.left };

  if (applyResult) {
    if (json) process.stdout.write(JSON.stringify(result, null, 2) + "\n");
    else printApplyResult(result);
    if (result.exitCode) process.exitCode = result.exitCode;
    return;
  }

  if (json) { process.stdout.write(JSON.stringify(result, null, 2) + "\n"); return; }
  printCleanPlan(result);
}

// ─── capacity ──────────────────────────────────────────────────────────
//
// waypost capacity [--json] — Decision 1 of the heavy-work-sized-to-the-
// machine ADR (WP-18): measure the machine's real free resources now, never
// cached, and say how many more heavy jobs it can take. Reaches
// scripts/capacity.mjs the way handleSize reaches sizes.mjs: a dynamic
// import(), in-process, no subprocess.
async function handleCapacity(args) {
  let capacity, presence;
  try {
    capacity = await import(SCRIPT_URL("capacity"));
    presence = await import(SCRIPT_URL("presence"));
  } catch (e) { fail(`capacity: ${e.message}`); }

  const releaseId = opt(args, "--release");
  if (releaseId != null) {
    await handleCapacityRelease(capacity, presence, releaseId, flag(args, "--force"), flag(args, "--json"));
    return;
  }

  const dir = slotsDir(presence);
  let holders;
  try { holders = capacity.readHolders({ dir, dirs: legacySlotsDirs(presence), authority: bootAuthority(capacity) }); }
  catch { holders = { live: [], stale: [] }; }

  let m;
  try {
    m = await capacity.measure({ holders: holders.live, env: process.env });
  } catch (e) { fail(`capacity: ${e.message}`); }
  warnIfProbed(m);

  if (flag(args, "--json")) {
    process.stdout.write(JSON.stringify({ ...m, holders_live: holders.live.map(holderSummary) }, null, 2) + "\n");
    return;
  }

  const availGb = (m.memory.available / GB).toFixed(1);
  const totalGb = (m.memory.total / GB).toFixed(1);
  process.stdout.write(`${m.cores} cores, load ${m.busy.toFixed(2)}; ${availGb} of ${totalGb} GB available (${m.probes.memory})\n`);
  if (m.can_start > 0) {
    process.stdout.write(`can start ${m.can_start} heavy job${m.can_start === 1 ? "" : "s"}\n`);
  } else {
    process.stdout.write(`can start 0 — ${m.reason}\n`);
  }
  if (holders.live.length) {
    process.stdout.write("\nholders:\n");
    for (const h of holders.live) process.stdout.write(`  ${holderLine(h)}\n`);
  }
}

function holderSummary(h) {
  return { id: h.id, session: h.session, harness: h.harness, command: h.command, since: h.started_at, host: h.host };
}

function holderLine(h) {
  return `${h.id}  ${h.session || "?"} (${h.harness || "?"})  ${h.command || ""}  since ${h.started_at}`;
}

// waypost capacity --release <id> [--force]: the recovery path when a slot
// looks stuck. slotLive() runs first — the same check readHolders() uses —
// and a record that still looks alive is refused without --force.
async function handleCapacityRelease(capacity, presence, id, force, json) {
  // An id names a record in the slot directory and nothing else: no path
  // separator and no dot, so --release can never reach a file outside it.
  if (!/^[A-Za-z0-9_-]+$/.test(String(id))) fail(`capacity --release: "${id}" is not a slot id`);
  const dir = slotsDir(presence);
  const file = [dir, ...legacySlotsDirs(presence)].map((d) => join(d, `${id}.json`)).find((p) => existsSync(p))
    || join(dir, `${id}.json`);
  if (!existsSync(file)) fail(`capacity --release: no such holder "${id}"`);
  let rec;
  try { rec = JSON.parse(readFileSync(file, "utf8")); }
  catch (e) { fail(`capacity --release: ${file}: ${e.message}`); }
  if (!rec || rec.id !== id || !rec.proc) fail(`capacity --release: ${file} is not a slot record for "${id}"`);
  const live = capacity.slotLive(rec, { authority: bootAuthority(capacity) });
  if (live && !force) {
    fail(`capacity --release: ${id} still looks alive (${rec.session || "?"} on ${rec.host}, pid ${rec.proc && rec.proc.pid}) — pass --force to release it anyway`);
  }
  try { unlinkSync(file); } catch (e) { fail(`capacity --release: ${e.message}`); }
  if (json) {
    process.stdout.write(JSON.stringify({ released: id, was_live: live, forced: live && force, record: holderSummary(rec) }, null, 2) + "\n");
  } else {
    process.stdout.write(`released ${holderLine(rec)}${live ? "  (forced, was still alive)" : ""}\n`);
  }
}

// ─── run --heavy: a machine-wide slot for heavy work ────────────────────
//
// WP-18 Decision 2. One slot table per machine, in the machine state
// directory (never synced): <machineStateDir()>/slots.<hostSlug>/. Every
// session, harness and project on this machine shares it. All writes to it —
// the lock, a new record, pruning a stale one — live here; scripts/capacity.mjs
// (readHolders, slotLive, bootIdentity) only ever reads it.
function slotsDir(presence) {
  return join(machineStateDir(), `slots.${presence.hostSlug()}`);
}

// The slot directories older versions kept under their state roots — on
// Windows one per packaged harness. Read beside slotsDir() for one release, so
// a heavy job an older Waypost still holds keeps refusing the next one; new
// claims and the lock always go to slotsDir().
function legacySlotsDirs(presence) {
  return legacyStateDirs().map((d) => join(d, `slots.${presence.hostSlug()}`)).filter((d) => existsSync(d));
}

const EX_TEMPFAIL = 75; // sysexits.h: temporary failure, safe to retry
const WAIT_POLL_MS = 5000;
const REASON_PRINT_MS = 30_000;

function delay(ms) {
  return new Promise((r) => setTimeout(r, ms));
}

// WAYPOST_CAPACITY_PROBE replaces the machine's real measures, for hermetic
// tests only. When it is honoured, say so on stderr, so a variable leaked
// into an interactive shell cannot silently fake an idle machine.
function warnIfProbed(m) {
  if (warnIfProbed.done || !m || !m.probes || m.probes.memory !== "WAYPOST_CAPACITY_PROBE") return;
  warnIfProbed.done = true;
  process.stderr.write("waypost: WAYPOST_CAPACITY_PROBE is set — the real machine is not being measured (tests only)\n");
}

// The boot authority (WP-18 amendment) is read at most once per `waypost`
// invocation, and only when something actually needs it: an epoch that
// disagrees. The claim, the lock and `--release` all share this one thunk, so
// a command that reads twenty records still spawns at most one PowerShell.
let BOOT_AUTHORITY = null;
function bootAuthority(capacity) {
  if (!BOOT_AUTHORITY) BOOT_AUTHORITY = capacity.authorityOnce();
  return BOOT_AUTHORITY;
}


// The identity fields a slot record, a claimSlot record and a
// waypost-removing/ marker all share — who and which process, on which
// boot, since when. Factored out of claimSlot (the amended machine-wide-
// limit ADR) so the detached deleter's own marker rewrite, and its parent's
// interim one, write the identical shape without re-deriving it by hand.
function selfMarker(capacity, presence) {
  const table = process.platform === "win32" ? null : presence.processTable();
  const self = table ? table.get(process.pid) : null;
  return {
    host: hostname().split(".")[0],
    proc: { pid: process.pid, started: self ? self.started : null, ticks: presence.startTicks(process.pid), comm: basename(process.execPath) },
    boot: capacity.bootIdentity(),
    // What an epoch mismatch is checked against later (WP-18 amendment):
    // the epoch in `boot` is itself drifted once the machine has slept, so
    // comparing THAT against a true boot time would delete live records.
    // null where the platform has no authority — such a record can then
    // only ever be kept, never pruned, which is the safe half.
    // The uptime at claim: a later reading below it confirms another boot
    // with no spawn at all (second amendment). Free on every platform.
    uptime: osUptime(),
    started_at: new Date().toISOString(),
  };
}

// The working directory a slot is claimed from, and — when it sits inside a
// repository — that repository's own root and common dir, both resolved to
// real paths (the amended machine-wide-limit ADR, Decision 4's own slot-
// record fields). One combined `git rev-parse`, so this costs one spawn, not
// two, on the path every heavy claim (including `run --heavy`'s own retry
// loop) goes through; computed BEFORE the slot lock is ever taken — nothing
// may spawn inside that critical section. Outside a repository, or when git
// itself is unavailable, `root`/`common` stay null and `cwd` is still
// reported: a live record with NEITHER is what capacity.blockingHolder
// treats as an unconditional block, so cwd alone is worth recording even
// there.
function slotWhere(dir) {
  const real = (p) => { try { return realpathSync(p); } catch { return p; } };
  const cwd = real(dir);
  let root = null;
  let common = null;
  try {
    const r = spawnSync("git", ["-C", dir, "rev-parse", "--path-format=absolute", "--show-toplevel", "--git-common-dir"],
      { encoding: "utf8", timeout: 5000 });
    if (r.status === 0) {
      const [top, commonDir] = String(r.stdout).trim().split(/\r?\n/);
      if (top) root = real(top);
      if (commonDir) common = real(commonDir);
    }
  } catch { /* no git: root/common stay null */ }
  return { cwd, root, common };
}

// Under the lock: prune the stale records, measure with the live ones, and
// either write our own record or report why not. Two processes starting in
// the same second cannot both pass the cap. `where` (slotWhere(), computed
// by the caller before the lock) is carried on the record so a live heavy
// job can be told apart from one working somewhere unrelated
// (capacity.blockingHolder) — null when the caller never computed one (kept
// optional so a caller with nothing meaningful to report, if one is ever
// added, is not forced to invent a location).
async function claimSlot(dir, argv, capacity, presence, where = null) {
  const lockDir = await acquireLock(dir, presence, capacity);
  if (!lockDir) {
    return { ok: false, reason: "the slot lock is busy — another `waypost run --heavy` is claiming right now" };
  }
  try {
    const holders = capacity.readHolders({ dir, dirs: legacySlotsDirs(presence), authority: bootAuthority(capacity) });
    for (const rec of holders.stale) { try { unlinkSync(rec.file); } catch {} }
    const m = await capacity.measure({ holders: holders.live, env: process.env });
    warnIfProbed(m);
    if (m.can_start <= 0) return { ok: false, reason: m.reason || "no heavy job slot available" };

    const id = `${process.pid}-${Date.now()}-${Math.random().toString(36).slice(2, 8)}`;
    const rec = {
      id,
      ...selfMarker(capacity, presence),
      // Filled in by recordAuthority() once the lock is released (third
      // amendment): reading it here cost a refusal 2486 ms against a 2000 ms
      // budget, came back null under load anyway, and moved the timings enough
      // that a claim slipped past a live lock owner in the suite.
      authority: null,
      cwd: where ? where.cwd : null,
      root: where ? where.root : null,
      session: process.env.WAYPOST_SESSION_ID || null,
      harness: process.env.WAYPOST_HARNESS || null,
      command: argv.map(shellQuote).join(" "),
    };
    const file = join(dir, `${id}.json`);
    writeFileSync(file, JSON.stringify(rec, null, 2) + "\n", "utf8");
    return { ok: true, id, file, release: () => { try { unlinkSync(file); } catch {} } };
  } finally {
    releaseLock(lockDir);
  }
}

// The authority is read AFTER the slot is claimed and the lock released, and
// its answer is written into the record we already own. Not before: a refusal
// must stay immediate (Decision 2's "exits at once", and the test that pins it
// under two seconds), and a spawn inside the lock serialises the other
// claimants. Atomically, because a reader that finds a half-written record
// skips it, and a skipped record is an unheld slot. No answer is not a
// failure: uptime carries the common case on its own (WP-18, third
// amendment).
function recordAuthority(file, capacity) {
  let asked;
  // Its own patient read, not the report path's memo: this is the one place
  // whose answer every later decision about this record depends on, and the
  // only cost of waiting is the start of a job that will run for minutes.
  try { asked = capacity.bootAuthority({ timeoutMs: capacity.AUTHORITY_WRITE_TIMEOUT_MS }); } catch { return; }
  if (!asked || !file) return;
  let rec;
  try { rec = JSON.parse(readFileSync(file, "utf8")); } catch { return; }
  if (!rec || rec.authority) return;
  try { writeFileAtomic(file, JSON.stringify({ ...rec, authority: asked }, null, 2) + "\n"); } catch {}
}

// <N>s or <N>m only, the ADR's own examples (30s, 10m) — anything else fails
// fast rather than guessing.
function parseDuration(spec) {
  const m = String(spec).match(/^(\d+)(s|m)$/);
  if (!m) return null;
  const n = Number(m[1]);
  return m[2] === "m" ? n * 60_000 : n * 1000;
}

function signalNumber(sig) {
  return (osConstants.signals && osConstants.signals[sig]) || 0;
}

// The retry line is printed to be pasted back, so an argument with anything
// beyond plain characters is quoted: POSIX single quotes, or double quotes on
// Windows.
function shellQuote(arg) {
  const s = String(arg);
  if (/^[\w@%+=:,./-]+$/.test(s)) return s;
  return process.platform === "win32" ? `"${s.replace(/"/g, '\\"')}"` : `'${s.replace(/'/g, "'\\''")}'`;
}

// ─── the automatic path at the end of `waypost run --heavy` ────────────
// (the amended machine-wide-limit ADR, Decision 4)

// WAYPOST_AUTOCLEAN_PROBE overrides the automatic path's own deadline, adds
// a synchronous pause after each rename, and substitutes for one statfs
// reading — for hermetic tests only, honoured only under NODE_TEST_CONTEXT
// (the same posture WAYPOST_CLEAN_NOW/WAYPOST_CAPACITY_PROBE already use),
// announced on stderr once. `deadline_ms` may only SHORTEN the real 60s
// deadline, never lengthen it — a test cannot accidentally let a real
// automatic sweep run longer than the ADR allows.
let warnedAutoCleanProbe = false;
function autoCleanProbe() {
  const raw = process.env.WAYPOST_AUTOCLEAN_PROBE;
  if (!raw || !process.env.NODE_TEST_CONTEXT) return null;
  let parsed;
  try { parsed = JSON.parse(raw); } catch { return null; }
  if (!parsed || typeof parsed !== "object") return null;
  if (!warnedAutoCleanProbe) {
    warnedAutoCleanProbe = true;
    process.stderr.write("waypost: WAYPOST_AUTOCLEAN_PROBE is set — the automatic cleanup path is not running unmodified (tests only)\n");
  }
  return parsed;
}

function autoCleanPause(ms, count) {
  if (!Number.isFinite(ms) || ms <= 0) return;
  process.stderr.write(`waypost: test pause after ${count} rename(s)\n`);
  const sab = new SharedArrayBuffer(4);
  Atomics.wait(new Int32Array(sab), 0, 0, ms);
}

// The vault path, read by hand: never readConfig() (which calls fail() —
// process.exit — on a config that exists but will not parse) and never
// bindingInfo()'s own throw either, though it does not throw in normal use.
// `unreadable` (a binding file that EXISTS but will not parse) is the one
// case the automatic path treats as a reason to skip — a config that is
// simply absent is an ordinary "no vault here".
function autoCleanVault() {
  let p;
  try { p = bindingInfo().path; } catch { return { vault: null, unreadable: true }; }
  if (!existsSync(p)) return { vault: null, unreadable: false };
  try {
    const cfg = JSON.parse(readFileSync(p, "utf8"));
    const raw = cfg && typeof cfg === "object" ? cfg.vault_path : null;
    if (!raw) return { vault: null, unreadable: false };
    const resolved = resolveVaultPath(raw);
    return { vault: resolved && existsSync(resolved) ? resolved : null, unreadable: false };
  } catch { return { vault: null, unreadable: true }; }
}

// Items whose owning entry keeps them off the automatic path entirely — a
// generic name, a distributable package inside, or auto: false — distinct
// from an ordinary "should" item nothing else is wrong with. Named in the
// report so "why isn't X touched" has an answer beyond "it wasn't picked".
function autoExcludedReasonOf(item) {
  if (item.scope !== "project" || item.origin === "project") return null;
  if (item.match === "generic") return "a generic name — release output lives there too, removed only by id";
  if (!(item.match === "tag" || item.match === "sure")) return null;
  if (item.holds_package === true) return `holds a distributable package${item.package ? ` (${item.package})` : ""}`;
  if (item.auto === false) return "opted out (auto: false)";
  return null;
}

function autoCleanupReport(rec) {
  if (rec.result === "failed") { process.stderr.write(`waypost: automatic cleanup failed — ${rec.reason}\n`); return; }
  if (rec.result === "skipped") { process.stderr.write(`waypost: automatic cleanup skipped — ${rec.reason}\n`); return; }
  if (rec.renamed.length) {
    const bytes = rec.renamed.reduce((s, r) => s + (r.bytes || 0), 0);
    process.stderr.write(`waypost: automatic cleanup renamed ${rec.renamed.length} item(s), ${(bytes / GB).toFixed(2)} GB, for removal\n`);
  }
  const freedBytes = rec.renamed.reduce((s, r) => s + (r.bytes || 0), 0);
  const stillShort = (rec.need || 0) - freedBytes;
  if (stillShort > 0) {
    if (rec.limit.kind === "gb") {
      process.stderr.write(`waypost: ${(stillShort / GB).toFixed(2)} GB over the limit is protected by the 7-day rule — raise it: \`waypost clean --limit <N>\`\n`);
    } else {
      process.stderr.write(`waypost: ${(stillShort / GB).toFixed(2)} GB short of the free-space floor — \`waypost size --global\` (${APFS_FREE_SPACE_NOTE})\n`);
    }
  }
  if (rec.deadline) process.stderr.write("waypost: automatic cleanup stopped at its 60s deadline\n");
  if (rec.excluded.length) process.stderr.write(`waypost: ${rec.excluded.length} idle item(s) never on the automatic path — waypost clean for detail\n`);
  if (rec.nested_skipped) process.stderr.write(`waypost: ${rec.nested_skipped} nested repository/repositories never entered\n`);
}

function safeRealpath(p) {
  try { return realpathSync(p); } catch { return p; }
}

// One JSONL line (matching scripts/cleanup.mjs's own logLine shape by
// hand — see `finish` above) plus the stderr report, for every outcome
// autoCleanup reaches past the very first (silent) check. A log-write
// failure here is reported inline, never thrown — the outcome itself was
// real work already decided, and losing the log must not hide it.
function logAndReportAuto(rec, host) {
  const line = JSON.stringify({ v: 1, ...rec });
  try { appendCleanLog(host, line); }
  catch (e) { process.stderr.write(`waypost: automatic cleanup's log line was not written: ${e.message}\n`); }
  autoCleanupReport(rec);
}

// The whole automatic path, run under the slot `run --heavy` still holds
// (the ADR, Decision 4), in the exact order the ADR lists its conditions.
// `ended` carries how the wrapped command finished: `status` (its own exit
// status, for the log's own `exit` field), `signal` (the signal that
// actually killed it, if any), `interrupted` (a signal THIS wrapper caught,
// even when the child then exited on its own terms — a tool trapping
// Ctrl-C and exiting 130 itself is treated exactly the same as one the
// signal killed outright), and `spawnFailed`. Every early return past the
// very first is logged (`kind: "auto"`) and briefly reported on stderr;
// the very first (no setting at all) is silent — a machine that never set
// a limit must see nothing from this at all.
async function autoCleanup({ claim, where, ended, capacity, presence }) {
  const host = presence.hostSlug();
  const setting = readCleanupSetting({ host });
  if (!setting || !setting.limit || setting.limit.kind === "off") return;

  const t0 = Date.now();
  const probe = autoCleanProbe();
  const deadlineMs = probe && Number.isFinite(probe.deadline_ms) ? Math.min(60000, probe.deadline_ms) : 60000;
  const deadline = t0 + deadlineMs;
  const session = process.env.WAYPOST_SESSION_ID || null;
  const limit = setting.limit;

  // Builds the log record only — never writes or reports it (logAndReportAuto
  // does that, right after every call site below): the very first checks run
  // before `cleanup` is even imported, so this cannot depend on
  // cleanup.logLine — it matches that function's own shape (v:1, plus every
  // field given) by hand instead.
  const finish = (result, reason, fields = {}) => ({
    kind: "auto", at: new Date().toISOString(), host, session,
    cwd: where ? where.cwd : null, root: where ? where.root : null,
    exit: ended.status, limit, result, reason: reason || null,
    ...fields,
  });

  try {
    if (ended.signal || ended.interrupted) return void logAndReportAuto(finish("skipped", `ended by ${ended.signal || ended.interrupted}`), host);
    if (ended.spawnFailed) return void logAndReportAuto(finish("skipped", "did not start"), host);
    if (!where || !where.root || !where.common) return void logAndReportAuto(finish("skipped", "not in a git work tree"), host);

    let cleanup;
    try { cleanup = await import(SCRIPT_URL("cleanup")); }
    catch (e) { return void logAndReportAuto(finish("failed", e.message), host); }

    // Pinned to the executable's own tree, never WAYPOST_HOME: an agent
    // pointing that elsewhere must not be able to steer which registry the
    // automatic path reads, the same reasoning as the gate in `--limit`.
    process.env.WAYPOST_PROJECT_DIR = where.root;
    const root = where.root;

    // First, whatever the conditions below decide (the ADR: "Any cleanup,
    // manual or automatic, first purges what an interrupted run left").
    const purge = purgeLeftovers(where, { capacity, presence });
    const adopted = purge.handed_off.length;

    const home = safeRealpath(homedir());
    if (cleanup.refusePath(root, { home, platform: process.platform })) {
      return void logAndReportAuto(finish("skipped", "a protected path", { adopted }), host);
    }

    const storage = presence.storageOf(root);
    if (storage.kind !== "local") {
      return void logAndReportAuto(finish("skipped", `on ${storage.provider} (${storage.kind}) — not local storage`, { adopted }), host);
    }

    let rootDev, commonDev;
    try { rootDev = statSync(root).dev; commonDev = statSync(where.common).dev; }
    catch (e) { return void logAndReportAuto(finish("failed", e.message, { adopted }), host); }
    if (commonDev !== rootDev) {
      return void logAndReportAuto(finish("skipped", "the git directory is on another filesystem", { adopted }), host);
    }

    const holdersNow = capacity.readHolders({ dir: slotsDir(presence), dirs: legacySlotsDirs(presence), authority: bootAuthority(capacity) });
    const blocking = capacity.blockingHolder(holdersNow.live, { self: claim.id, root, platform: process.platform, canon: safeRealpath });
    if (blocking) {
      return void logAndReportAuto(finish("skipped", `another heavy job overlaps this tree (${blocking.holder.id})`, { adopted }), host);
    }

    const { vault, unreadable } = autoCleanVault();
    if (unreadable) {
      return void logAndReportAuto(finish("skipped", "the project binding is unreadable", { adopted }), host);
    }
    if (vault) {
      const shared = presence.sharedTree(vault, { self: process.env.WAYPOST_SESSION_ID || null, contain: true });
      if (shared.shared) {
        const who = presence.sharedWith ? presence.sharedWith(shared) : shared.with.map((w) => `${w.session} on ${w.host}`).join("; ");
        return void logAndReportAuto(finish("skipped", `shared with ${who}`, { adopted }), host);
      }
    }

    if (Date.now() > deadline) {
      return void logAndReportAuto(finish("skipped", "deadline", { adopted }), host);
    }

    let sizes, toolchains, discovery;
    try {
      sizes = await import(SCRIPT_URL("sizes"));
      toolchains = await import(SCRIPT_URL("toolchains"));
      discovery = await import(SCRIPT_URL("discovery"));
    } catch (e) { return void logAndReportAuto(finish("failed", e.message, { adopted }), host); }
    const mods = { cleanup, sizes, toolchains, presence, discovery };

    // The registry itself, not only its own resolution above: loadRegistry
    // (inside gatherCleanContext) reads pluginRoot(), which honours
    // WAYPOST_HOME/CLAUDE_PLUGIN_ROOT — pinned to this executable's own
    // tree for exactly as long as that one call needs it.
    const savedHome = process.env.WAYPOST_HOME;
    process.env.WAYPOST_HOME = ROOT;
    let ctx;
    try {
      ctx = gatherCleanContext(mods, { root, vault, includeMachine: false, walk: { stopAtGit: true, locators: false, deadline } });
    } finally {
      if (savedHome === undefined) delete process.env.WAYPOST_HOME; else process.env.WAYPOST_HOME = savedHome;
    }

    if (ctx.scan && ctx.scan.stopped_by === "deadline") {
      return void logAndReportAuto(finish("ran", "deadline", {
        counted: 0, need: 0, shortfall: 0, renamed: [], skipped_items: [], stayed: [], excluded: [],
        nested_skipped: ctx.scan.nested_skipped, deadline: true, elapsed_ms: Date.now() - t0,
        deleter_pid: null, adopted, ...(lastCleanNowHonored ? { clock: process.env.WAYPOST_CLEAN_NOW } : {}),
      }), host);
    }

    const now = cleanNow();
    const classified = planFromContext(ctx, cleanup, now);

    let shortfall = 0;
    let dev = null;
    if (limit.kind === "free") {
      if (probe && probe.statfs) {
        shortfall = cleanup.shortfallOf({ size: probe.statfs.size, avail: probe.statfs.avail }, limit.percent);
      } else {
        try {
          const s = statfsSync(root);
          shortfall = cleanup.shortfallOf({ size: s.blocks * s.bsize, avail: s.bavail * s.bsize }, limit.percent);
        } catch { /* best effort — shortfall stays 0 */ }
      }
      try { dev = statSync(root).dev; } catch { /* best effort */ }
    }
    const { counted, need, eligible } = cleanup.limitNeed(classified, limit, now, { shortfall, dev });
    // "should" alone would miss a generic name — capped at "can" by
    // classifyItem itself, never "should", however idle — so this checks
    // every non-"keep" item instead: the report's own point is "why isn't
    // this on the automatic path", and a generic name is exactly such a
    // case, not merely idle.
    const excludedList = classified
      .filter((it) => it.class !== "keep" && autoExcludedReasonOf(it))
      .map((it) => ({ id: it.id, path: it.rel || it.path, reason: autoExcludedReasonOf(it) }));

    const removingDir = join(where.common, REMOVING_DIR);
    const marker = selfMarker(capacity, presence);
    const renamed = [];
    const skippedItems = [];
    let freed = 0;
    let deadlineHit = false;
    let holderBlocked = null;
    const oldSlots = legacySlotsDirs(presence);
    let i = 0;
    for (; i < eligible.length; i++) {
      if (freed >= need) break;
      if (Date.now() > deadline) { deadlineHit = true; break; }
      const holders = capacity.readHolders({ dir: slotsDir(presence), dirs: oldSlots, authority: bootAuthority(capacity) });
      const hit = capacity.blockingHolder(holders.live, { self: claim.id, root, platform: process.platform, canon: safeRealpath });
      if (hit) { holderBlocked = hit; break; }
      const item = eligible[i];
      const rc = recheckItem(item, ctx, mods, now);
      if (rc.changed || !cleanup.qualifiesForLimit({ ...rc.item, class: rc.class }, now)) {
        skippedItems.push({ id: item.id, path: item.rel || item.path, reason: rc.changed ? "changed since the plan was built" : (rc.reason || "no longer qualifies") });
        continue;
      }
      const renResult = renameForRemoval(item, removingDir, marker);
      if (!renResult.ok) {
        skippedItems.push({ id: item.id, path: item.rel || item.path, reason: renResult.reason });
        continue;
      }
      const bytes = Number.isFinite(rc.fresh.bytes) ? rc.fresh.bytes : item.bytes;
      renamed.push({ id: item.id, path: item.rel || item.path, bytes, name: renResult.name });
      freed += bytes || 0;
      autoCleanPause(probe && probe.pause_ms, renamed.length);
    }
    const stayed = eligible.slice(i).map((it) => ({ id: it.id, path: it.rel || it.path, bytes: it.bytes }));
    const deleterPid = renamed.length ? spawnDeleter(removingDir, renamed.map((r) => r.name), marker) : null;

    const reason = deadlineHit ? "deadline" : (holderBlocked ? `another heavy job overlaps this tree (${holderBlocked.holder.id})` : null);
    return void logAndReportAuto(finish("ran", reason, {
      counted, need, shortfall, renamed, skipped_items: skippedItems.slice(0, 20),
      stayed: stayed.slice(0, 20), excluded: excludedList.slice(0, 20),
      nested_skipped: ctx.scan ? ctx.scan.nested_skipped : 0, deadline: deadlineHit,
      elapsed_ms: Date.now() - t0, deleter_pid: deleterPid, adopted,
      ...(lastCleanNowHonored ? { clock: process.env.WAYPOST_CLEAN_NOW } : {}),
    }), host);
  } catch (e) {
    return void logAndReportAuto(finish("failed", e.message), host);
  }
}

// Lowers waypost's own priority first, so the command and everything it
// starts inherits it — Node maps PRIORITY_BELOW_NORMAL to nice +10 on POSIX,
// below-normal on Windows. No shell, except a .cmd/.bat target on Windows,
// which only cmd.exe can start (the argv is the caller's own command, not
// data from a registry).
// `claim` (not just its own release()) and `where` (the amended machine-
// wide-limit ADR): the automatic cleanup runs AFTER the wrapped command
// exits but BEFORE the slot is released, under the same claim — and needs
// both. Nothing on this whole path may call fail() or readConfig() (both
// call process.exit): a bug in the cleanup must never take the wrapped
// command's own already-decided exit status down with it.
// A probe, not a guess from XDG_RUNTIME_DIR: systemd-run fails the same way
// (exit 1) for an unreachable manager and for a command that exits 1, so the
// choice is made before the job starts.
function ownScopeAvailable(env) {
  const r = spawnSync("systemd-run", ["--user", "--scope", "--quiet", "--collect", "--", "true"], { stdio: "ignore", timeout: 5000, env });
  return r.status === 0;
}

async function runHeavy(argv, claim, where, mods) {
  try { setPriority(osConstants.priority.PRIORITY_BELOW_NORMAL); }
  catch { /* best-effort: a restricted sandbox must not block the run */ }
  // Linux: if memory runs out anyway, the kernel's OOM killer takes this job
  // first, not the harness beside it (ADR "Memory for heavy work: half the
  // memory up to 2 GB, …"; the job's own scope below keeps systemd from
  // taking the harness down with it). Inherited across fork and exec; raising needs no
  // privilege, lowering would, so a higher value already set is left alone.
  if (process.platform === "linux") {
    try {
      if (Number(readFileSync("/proc/self/oom_score_adj", "utf8")) < 1000) writeFileSync("/proc/self/oom_score_adj", "1000");
    } catch { /* best-effort, like the priority above */ }
  }

  // The command is arbitrary and may itself invoke `waypost` (this project's
  // own test suite does, extensively): it must see the environment it was
  // actually given, not this wrapper's own session/harness identity — pinned
  // onto process.env above by main(), for ITS OWN heartbeat/commit labelling
  // — when that identity was only invented (detected), not passed in. Left
  // leaking through, a nested `waypost` call would skip its OWN derivation
  // (main() only pins when unset) and inherit this wrapper's, which is how a
  // `waypost run --heavy -- node --test …` run once produced a session id
  // collision in an unrelated test.
  // The harness process (WAYPOST_PROC) is always derived, never passed in by a
  // caller, so a nested `waypost` must find its own the same way.
  const childEnv = { ...process.env };
  if (INHERITED_SESSION_ID === undefined) delete childEnv.WAYPOST_SESSION_ID;
  if (INHERITED_HARNESS === undefined) delete childEnv.WAYPOST_HARNESS;
  if (INHERITED_PROC === undefined) delete childEnv.WAYPOST_PROC;

  let [cmd, ...cmdArgs] = argv;
  const useShell = process.platform === "win32" && /\.(cmd|bat)$/i.test(cmd);
  // Linux under a systemd user manager: the job gets a scope of its own. The
  // OOM killer's victim is only half of it — systemd then stops the whole
  // unit the victim sat in (DefaultOOMPolicy=stop), and that unit is the
  // harness's own app scope when the job runs in it: the 2026-09-27 VM
  // incident, reproduced 2026-10-13. `--scope` execs the command in place, so
  // its pid, signals, environment and exit status stay this child's. Without
  // a reachable user manager the command runs as before.
  if (process.platform === "linux" && ownScopeAvailable(childEnv)) {
    cmdArgs = ["--user", "--scope", "--quiet", "--collect", "--", cmd, ...cmdArgs];
    cmd = "systemd-run";
  }

  // A signal THIS wrapper itself caught — set the moment it arrives, so a
  // tool that traps Ctrl-C and exits 130 on its own terms (never actually
  // killed BY the signal, so `signal` below stays null) is treated exactly
  // the same as one the signal killed outright: either way, cleanup must
  // never run against a command that did not finish on its own.
  let interrupted = null;
  let child = null;
  const onSigint = () => { interrupted = "SIGINT"; if (child) { try { child.kill("SIGINT"); } catch {} } };
  const onSigterm = () => { interrupted = "SIGTERM"; if (child) { try { child.kill("SIGTERM"); } catch {} } };
  process.on("SIGINT", onSigint);
  process.on("SIGTERM", onSigterm);

  let spawnFailed = false;
  let code = null;
  let signal = null;
  try {
    child = spawn(cmd, cmdArgs, { stdio: "inherit", shell: useShell, env: childEnv });
    [code, signal] = await new Promise((res) => {
      child.on("exit", (c, s) => res([c, s]));
      child.on("error", (e) => {
        spawnFailed = true;
        process.stderr.write(`waypost run --heavy: ${e.message}\n`);
        res([127, null]);
      });
    });
  } catch (e) {
    spawnFailed = true;
    process.stderr.write(`waypost run --heavy: ${e.message}\n`);
    code = 127;
  }

  // Default handling again: a signal that arrives DURING the cleanup below
  // ends this process at once (the ADR: "A signal that arrives during the
  // cleanup ends the process at once, with 128+n") — renaming an item
  // before it is ever actually deleted is what keeps that safe.
  process.removeListener("SIGINT", onSigint);
  process.removeListener("SIGTERM", onSigterm);

  const status = signal ? 128 + signalNumber(signal) : (code == null ? 1 : code);
  process.exitCode = status;

  try {
    await autoCleanup({
      claim, where, ended: { status, signal, interrupted, spawnFailed },
      capacity: mods.capacity, presence: mods.presence,
    });
  } catch (e) {
    process.stderr.write(`waypost: automatic cleanup failed: ${e.message}\n`);
  } finally {
    claim.release();
  }
  process.exitCode = status;
}

// waypost run --heavy [--wait <Ns|Nm>] -- <argv…>. No wait: refuse at once,
// with the reason and the exact retry command, exit EX_TEMPFAIL. --wait
// retries every 5 seconds until the deadline, repeating the reason every 30.
async function handleRun(args) {
  if (!flag(args, "--heavy")) fail('run: only "run --heavy -- <argv…>" is supported (see `waypost help`)');
  const { tail: argv } = splitAtTerminator(args);
  if (!argv.length) fail("run --heavy: usage: waypost run --heavy [--wait <Ns|Nm>] -- <argv…>");

  let waitMs = null;
  const waitSpec = opt(args, "--wait");
  if (waitSpec != null) {
    waitMs = parseDuration(waitSpec);
    if (waitMs == null) fail(`run --heavy: --wait expects <N>s or <N>m, got "${waitSpec}"`);
  }

  let capacity, presence;
  try {
    capacity = await import(SCRIPT_URL("capacity"));
    presence = await import(SCRIPT_URL("presence"));
  } catch (e) { fail(`run --heavy: ${e.message}`); }

  const dir = slotsDir(presence);
  try { ensureMachineStateDir(dir); } catch (e) { fail(`run --heavy: ${stateWriteHint(dir, e)}`); }
  const retryCmd = `waypost run --heavy -- ${argv.map(shellQuote).join(" ")}`;
  const deadline = waitMs != null ? Date.now() + waitMs : null;
  let lastPrinted = 0;
  // Computed once, before the wait loop: the command's own working directory
  // never changes while this process waits, and nothing may spawn inside
  // claimSlot's own lock either way.
  const where = slotWhere(process.cwd());

  for (;;) {
    const claim = await claimSlot(dir, argv, capacity, presence, where);
    if (claim.ok) {
      recordAuthority(claim.file, capacity);
      await runHeavy(argv, claim, where, { capacity, presence });
      return;
    }

    const now = Date.now();
    if (deadline == null || now >= deadline) {
      process.stderr.write(`waypost run --heavy: refused — ${claim.reason}\n  retry: ${retryCmd}\n`);
      // A holder whose boot could not be confirmed is kept rather than pruned
      // (WP-18 amendment), so the way out of a phantom has to be said out
      // loud: the only other one is waiting for the 24-hour cap.
      if (/^slots:/.test(String(claim.reason || ""))) {
        process.stderr.write("  who holds it: waypost capacity"
          + "     (a holder that is not really there: waypost capacity --release <id> --force)\n");
      }
      process.exitCode = EX_TEMPFAIL;
      return;
    }
    if (now - lastPrinted >= REASON_PRINT_MS) {
      process.stderr.write(`waypost run --heavy: waiting — ${claim.reason}\n`);
      lastPrinted = now;
    }
    await delay(Math.min(WAIT_POLL_MS, deadline - now));
  }
}

// ─── status ────────────────────────────────────────────────────────────

// The machine-wide cleanup-limit setting and the last automatic outcome
// (the amended ADR) — a machine-level fact, so it shows even for a project
// with no vault bound yet. Never throws: a broken read here must not take
// the rest of `waypost status` down with it.
async function cleanupStatusLine() {
  try {
    const presence = await import(SCRIPT_URL("presence"));
    const cleanup = await import(SCRIPT_URL("cleanup"));
    const host = presence.hostSlug();
    const setting = readCleanupSetting({ host });
    if (!setting) return "cleanup  none\n";
    const how = setting.gate && setting.gate.answer === true ? "terminal"
      : setting.gate && setting.gate.required === false ? "no gate required" : "gate";
    const checked = setting.gate ? setting.gate.checked : "unknown";
    let line = `cleanup  ${cleanup.formatLimit(setting.limit)} — set ${String(setting.set_at).slice(0, 10)} (${how}; gate: ${checked})\n`;
    const outcome = readLastAutoCleanup({ host });
    if (outcome) line += `        last run ${cleanup.formatOutcome(outcome)}\n`;
    return line;
  } catch {
    return "cleanup  none\n";
  }
}

async function handleStatus() {
  const p = configPath();
  const cfg = readConfig();
  process.stdout.write(`waypost ${VERSION}\n`);
  process.stdout.write(await cleanupStatusLine());
  if (!cfg) {
    process.stdout.write(`config  (none — run \`waypost bind <vault-path>\`)\n        expected at ${p}\n`);
    return;
  }
  process.stdout.write(`config  ${p}${bindingInfo().inherited_from ? `  (inherited from the main worktree ${bindingInfo().inherited_from})` : ""}\n`);
  process.stdout.write(`vault   ${cfg.vault_path || "(unset)"}${cfg.vault_path && !existsSync(cfg.vault_path) ? "  ⚠️ missing" : ""}\n`);
  process.stdout.write(`layout  ${cfg.layout || "engineering"}\n`);
  process.stdout.write(`lang    ${cfg.language || "en"}\n`);
  const a = cfg.agents || {};
  const pins = [
    ...(a.default && a.default.model ? [`default=${a.default.model}`] : []),
    ...Object.entries(a.per_agent || {}).map(([k, v]) => v && v.model ? `${k}=${v.model}` : null),
    ...Object.entries(a.per_harness || {}).map(([k, v]) => v && v.model ? `harness:${k}=${v.model}` : null),
  ].filter(Boolean);
  if (pins.length) process.stdout.write(`models  ${pins.join(" · ")}\n`);
  process.stdout.write("\n");
  // Who else is live on this vault, before anything about roles: on a shared
  // vault that is the fact that changes what you should do next.
  run("sessions", []);
  // Roles: a count, not five paragraphs. `waypost agents list` is one command away
  // when the detail is actually wanted.
  const st = JSON.parse(run("agents", ["list", "--json"], { capture: true }) || "{}");
  const per = (st.install || []).filter((h) => h.roles.some((r) => r.state !== "absent" && r.state !== "n/a"))
    .map((h) => `${h.harness}: ${h.roles.filter((r) => r.state === "current").length}/${h.roles.length}`);
  process.stdout.write(`roles   ${(st.roles || []).length} defined · ${per.length ? per.join(" · ") : "not installed"}`
    + `  (waypost agents list)\n`);
}

// Bare `waypost` is the most likely first thing anyone types. Answer the two
// questions they actually have — is this set up, and what do I do — rather than
// printing a manual.
function handleDefault() {
  const cfg = readConfig();
  if (!cfg || !cfg.vault_path) {
    process.stdout.write(`waypost ${VERSION} — not set up in ${projectRoot()}\n\n`
      + "  waypost setup         bind a vault, install the roles for this project's harnesses,\n"
      + "                    register them, and repair anything mechanical\n"
      + "  waypost setup --dry-run   see what that would do first\n"
      + "  waypost help          every command\n");
    return;
  }
  process.stdout.write(`waypost ${VERSION} · vault ${cfg.vault_path}\n\n`);
  handleNext([]);
  process.stdout.write("\nwaypost brief (orientation) · waypost help (every command)\n");
}

function help() {
  process.stdout.write(`waypost — Waypost ${VERSION}

USAGE
  waypost <command> [args]
  waypost <command> [args] -- <literal positional, even if it looks like a flag>

START HERE
  setup                    do the whole install: bind a vault, scaffold it,
                           install the roles for the harnesses this project
                           uses, register them, repair the mechanical findings
                           [--vault <path>] [--harness <id>] [--dry-run]
  next                     what this project needs right now, ranked, with the
                           command for each

VAULT
  bind <vault-path>        bind a vault and scaffold the layout (alias: init)
                           [--layout <name>] [--lang <en|ru|es|de|fr|zh>] [--force]
                           [--self-install off|on: whether brief installs roles]
  scaffold                 (re)create the layout's folders and index READMEs
  status                   bound-vault summary + agent-role install state
  draft <kind> "<title>"   render an artifact; --write creates it and reconciles
                           (epic/story take a leading id: draft epic <ID> "…",
                            draft story <EPIC> "…")
                           kinds: adr spec epic story research concept meeting runbook
  story <plan|close> <p>   story lifecycle gate; --write applies
  kanban | graph | codemap regenerate one derived view (--json to preview only)
  graph --for <path>       one artifact's typed neighbourhood, instead of
                           reading a graph that grows with the vault
  search "<text>"          vault-wide search returning pointers, not documents
                           [--kind adr|spec|story|…] [--limit N]
  reconcile [--write]      re-derive every view (indexes, kanban, code-map, graph)
  brief                    session-start orientation packet (run it when you
                           start work: where things live, what is in flight)
  doctor [flags]           deterministic diagnostics (--install|--vault [<path>]|--fix);
                           --vault <path> needs no binding (CI on a fresh clone)
  diff-refs [flags]        changed-file evidence for code_refs

WORKING IN SEVERAL HARNESSES AT ONCE
  commit -m "<what>"       commit with the trailers that say which harness,
                           session, OS and story it came from [--story <id>]
                           [--task <id>: an external tracker's task id, repeatable]
                           [--all: everything not ignored | --tracked]
                           [--dry-run] [-- <paths>]
  merge <ref>              merge, re-derive the views, then commit — so the
                           board in the merge commit matches the merged vault
  log [--story|--task|--harness|--provider|--session|--os <v>]
                           the history, read back through those trailers
                           (--os takes darwin, linux or win32, not "macos")
  sessions --claim <story> tell the other live sessions what you are on
  lease <path…>            announce the files you are editing right now, so a
                           session on another device does not touch them
                           (lease list | lease release [path…])
  watch                    stay live: beat on an interval and report who joins,
                           leaves or picks up a story on another device
  team status [<id>]       experimental host-local task authority and inboxes
  team create <task>       --native-policy-bootstrap prepares protocol calibration
  team refresh <id>        refresh automatic model-strength evidence
  team watch <id>          periodically check evidence [--interval <seconds>]
  team route <id>          preview a manifest [--request-file <json>]; no grant
  team roles <id>          list participants and their observed identity; --assign --coordinator a,b --reviewers c --executors d --reason "<why>" --yes sets roles (owner)
  team host <id>           managed endpoints, relay, review and owned Git flow
  team budget set|status|clear  the machine's token budget for live runs (set --name N --cap <schema>=<n> [--total <n>] --yes --reason "<why>")
                           --operation bootstrap|inspect|relay|review|checkout|
                           candidate|dispatch|publish|recover-publication
                           native-policy-install --cohort <id> --policy-revision <n>
  team-mcp                cooperative stdio inbox tools; --project, --team,
                          --credential (absolute paths); no native wake proof
  team-mcp-config         preview project MCP snippet; --harness, --project,
                          --team, --credential, --name; --write creates only
                          an absent project config, never overwrites settings
                           current scope and limits: docs/team-coordination.md
  storage                  what the vault is stored on and how far behind
                           another device's presence can be
  merge-derived <file>     git merge driver: regenerate a derived view instead
                           of merging two machine-written copies of it

ROLES (same roles in every harness)
  agents list              roles + per-harness install state
  agents show <role>       print the role prompt (fresh-context handoff)
  harnesses                every harness waypost can render roles for, and where
                           they land (* = detected here)
  agents install           render the roles into the harnesses this project
                           uses  [--harness <id>[,<id>…]|all]
  agents uninstall         remove generated role files
  agents register          write the routing block into AGENTS.md / CLAUDE.md
  agents unregister        remove that routing block again  [--dry-run]
  agents model <role|default|harness:<name>> <id>
                           pin a model; role/default reach only harnesses with
                           a published tier naming, harness:<name> the rest

PROCEDURES
  prompt [name]            print a workflow procedure (the verified loop's steps)
  skill [name]             print a bundled skill (waypost-<name> or <name>)
  skills …                 Agent Skills in this project: install [--harness <id,…>|all], list, uninstall, validate
  launcher [--write]       the command on PATH: is it npm's symlink into a checkout that loses its
                           executable bit (one another OS edits)? --write replaces it with a shim
  ready [--all] [--json]   stories that are planned, unblocked (blocked_by, draft spec, proposed ADR) and unclaimed, with the claim command
  sessions [--touch]       active-session registry (--claim/--release/--prune [--older-than 6h])
  tokens [flags]           what the loop cost, from Claude Code transcripts
                           (Claude-only: no other harness writes them)
  profile [--refresh]      the scheme of what waypost works with: detected
                           tools, their cache paths (asked, then env, then
                           default) and the project's ecosystems — rebuilt
                           when missing, older than 30 days, or --refresh
                           [--json]
  size [--project [dir]]   build-artifact sizes, read-only — measures, never
                           deletes; needs no bound vault [--budget <n>] [--json]
  size --global            toolchain/package-manager caches, simulators,
                           containers and temp dirs ≥ 0.1 GB, each with its
                           own clean command — measures a fresh machine
                           profile's paths when one exists [--json for the rest]
  clean [--json]           a classified plan over the project and the machine
                           at once (keep / should / can, with why) — read-only
  clean --apply <id…>|should [--yes --reason "<who agreed, when>"]
                           remove exactly those ids, or every should item;
                           can only by id, keep and manual always refused;
                           re-checked right before each removal, one failure
                           never stops the rest [--json for the full report]
                           on a terminal with no harness detected, asks
                           [y/N] (60s, no otherwise); a harness or no
                           terminal needs --yes --reason
  clean --limit [<N>|free:<P>%|off]
                           the machine-wide automatic-cleanup limit — no
                           value prints the current setting and the last
                           automatic outcome; setting or tightening it needs
                           your own terminal, with no harness detected, and
                           a preview before the [y/N]; off and loosening it
                           work from anywhere [--json]
  capacity [--json]        the machine's real free resources right now: cores,
                           load, available memory and how many more heavy
                           jobs it can take (never cached) [--json for detail]
  capacity --release <id> [--force]
                           recovery path for a stuck slot: refuses a
                           live-looking holder unless --force is given
  run --heavy -- <cmd…>    claim a machine-wide slot, run at lowered priority
                           (nice +10), and release it on exit
                           [--wait <Ns|Nm>] (refused: exit 75, with the
                           reason and the retry command)

HARNESS-AGNOSTIC
  No hooks, no status line, no slash commands: the CLI is the interface, and
  the roles are rendered into whatever each harness understands. A harness is a
  JSON file in harnesses/ — add your own in .waypost/harnesses/ (waypost harnesses).
  Project root: WAYPOST_PROJECT_DIR (else cwd). Tool root: the tree this
  executable belongs to (WAYPOST_HOME applies to a script run directly).
`);
}

// ─── lease ─────────────────────────────────────────────────────────────
//
// AGENTS.md and this file's own help() document `waypost lease <path…>` — a path
// as the first token, not a subcommand. presence.mjs's own CLI takes
// `lease|acquire|release|list|watch|storage` as its first token, so a path
// forwarded unchanged reads as an unknown subcommand. Insert the implied
// "lease" subcommand unless the caller already named a real one, or gave only
// flags (`waypost lease --json`, read as "list mine, as json" — there is no path
// to lease, so there is nothing to insert "lease" in front of).
const LEASE_SUBCOMMANDS = new Set(["lease", "acquire", "release", "list", "watch", "storage"]);
function leaseArgs(rest) {
  if (!rest.length) return ["list"];
  if (LEASE_SUBCOMMANDS.has(rest[0])) return rest;
  if (rest[0].startsWith("--")) return ["list", ...rest];
  return ["lease", ...rest];
}

// Presence is only useful if it happens without being asked. Every command that
// implies work beats the session's heartbeat, so another device sees this
// session without anyone remembering `waypost sessions --touch`. Never fails the
// command, never runs for a read-only lookup, and WAYPOST_NO_BEAT=1 turns it off.
// "clean" is deliberately NOT here, unlike "size": it is a working command
// that will remove things once --apply lands (the next commit), so it beats
// the heartbeat like any other write-side command; a plan-only run today
// costs one extra beat, which is cheap.
const QUIET_COMMANDS = new Set(["help", "--help", "-h", "version", "--version", "-v",
  "harnesses", "prompt", "skill", "skills", "agents", "log", "storage", "merge-derived", "size", "capacity"]);

// ─── brief: the session start also installs its own harness ───────────
//
// `waypost setup` installs roles for the harnesses the PROJECT shows evidence
// of (a .codex/ directory, a CLAUDE.md with the user's own content). A harness
// that simply opens the project for the first time has left no such evidence
// yet — but the session running this command knows what it is (the registry's
// env markers, or WAYPOST_HARNESS, pinned by heartbeat()). So the session-start
// command renders the roles of the harness it runs in when they are absent or
// stale, makes sure that harness's own instruction file carries the routing
// block, and says what it wrote — those files are committed by convention, and
// git carries them to every other machine and harness. Nothing is written when
// nothing is missing; `--no-install` (or WAYPOST_NO_INSTALL=1) reads only, and
// `"self_install": "off"` in the vault policy does the same for every clone.
async function selfInstall(rest) {
  if (rest.includes("--no-install") || process.env.WAYPOST_NO_INSTALL) return;
  const cfg = readConfig();
  if (!cfg || !cfg.vault_path || !existsSync(cfg.vault_path)) return;
  if (selfInstallOff(cfg.vault_path)) return; // the vault said no, for every clone
  let current = process.env.WAYPOST_HARNESS || "unknown";
  try {
    const A = await import(SCRIPT_URL("agents"));
    const S = await import(SCRIPT_URL("skills"));
    withRegistryHome(() => {
      const h = process.env.WAYPOST_HARNESS || A.detectHarness();
      if (!h || h === "unknown" || !A.harnessIds().includes(h)) return;
      current = h;
      const proj = projectRoot();
      const did = [];
      const st = A.status({ proj, cfg, ids: [h] })[0];
      if (st && st.roles.some((r) => r.state === "absent" || r.state === "stale")) {
        const wrote = A.install([h], { proj, cfg }).filter((r) => r.action === "created" || r.action === "updated");
        if (wrote.length) did.push(`installed ${wrote.length} role file(s) into ${(A.harness(h).roles || {}).dir || "its agents directory"}/`);
      }
      const targets = A.instructionTargetFor(h, proj);
      const reg = targets.length ? A.register({ proj, cfg, files: targets }).filter((r) => r.action !== "unchanged") : [];
      if (reg.length) did.push(`${reg[0].action} the routing block in ${reg.map((r) => r.file).join(", ")}`);
      // Skills too: the same standard file for every harness, in the directory
      // this harness discovers (registry data); one copy serves every harness
      // that reads the shared .agents/skills.
      const sk = A.skillsOf(h);
      if (sk) {
        const st = S.status({ proj, ids: [h] })[0];
        if (st && st.skills.some((r) => r.state === "absent" || r.state === "stale")) {
          const wrote = S.install([h], { proj }).filter((r) => r.action === "created" || r.action === "updated");
          if (wrote.length) did.push(`installed ${wrote.length} skill(s) into ${sk.dir}/`);
        }
      }
      if (!did.length) return;
      const note = `This session runs in ${h}, which this project was not set up for yet — ${did.join("; ")}. `
        + "Commit them, so every machine and harness gets the same roles (`waypost brief --no-install` reads only).\n\n";
      (rest.includes("--json") ? process.stderr : process.stdout).write(note);
    });
  } catch (e) {
    process.stderr.write(`waypost brief: could not repair ${current}: ${e.message}\n`
      + "Some files may have been installed before the failure; rerun `waypost brief` after fixing the cause.\n");
  }
}

async function heartbeat(cmd) {
  if (QUIET_COMMANDS.has(cmd) || process.env.WAYPOST_NO_BEAT) return;
  try {
    // Harness and session id are already resolved and pinned in the environment
    // by main() (G-1, E-3): the child this command spawns (sessions, lease,
    // watch, status, brief) labels the session the way commits do.
    const { beat } = await import(SCRIPT_URL("presence"));
    const cfg = readConfig();
    if (cfg && cfg.vault_path && existsSync(cfg.vault_path)) {
      beat(cfg.vault_path, process.env.WAYPOST_SESSION_ID, { harness: process.env.WAYPOST_HARNESS || null });
    }
  } catch { /* presence is advisory; a command must never fail because of it */ }
}

// Machine state moved to one root on every OS (the global-rules ADR,
// Decision 1). Whatever an older version left under its own root — on Windows
// one per packaged harness — moves on the first command that finds it; a
// failure is reported and retried next time, never fatal.
async function migrateStateIfNeeded() {
  // The suite's own children never move a developer's real state; a budget
  // still waiting in an old root refuses on its own (run-budget.mjs), so
  // leaving the move for later never opens anything.
  if (process.env.WAYPOST_NO_STATE_MIGRATION === "1") return;
  try {
    // Only roots under this process's own home, or any when that home is the
    // account's: a command run with HOME/USERPROFILE pointed elsewhere never
    // carries the owner's real state there (lib.mjs legacyDirsToMove).
    const from = legacyDirsToMove();
    // A root with something to move that this process may not move: say why,
    // and what to do — otherwise the budget refusal is a dead end.
    const movable = new Set(from);
    const all = legacyStateDirs();
    const stuck = all.filter((d) => !movable.has(d));
    if (stuck.length) {
      const mig0 = await import(SCRIPT_URL("state-migrate"));
      let account = null;
      try { account = (await import("node:os")).userInfo().homedir; } catch {}
      for (const d of stuck) {
        if (!mig0.pendingEntries(d).length) continue;
        process.stderr.write(`waypost: machine state: ${d} is not moved — this process's home (${homedir()}) is not the account's own (${account || "unknown"}). Run any waypost command as the account itself, or move its files into ${accountStateDir() || "the account's own ~/.local/state/waypost"} by hand.\n`);
      }
    }
    if (!from.length) return;
    const mig = await import(SCRIPT_URL("state-migrate"));
    if (!from.some((d) => mig.pendingEntries(d).length)) return;
    const [presence, capacity] = await Promise.all([import(SCRIPT_URL("presence")), import(SCRIPT_URL("capacity"))]);
    const report = await mig.migrateMachineState({ to: machineStateDir(), from, deps: { presence, capacity } });
    for (const line of report) process.stderr.write(`waypost: machine state: ${line}\n`);
  } catch (e) {
    process.stderr.write(`waypost: machine state: could not move it yet (${e.message}) — tried again next run\n`);
  }
}

async function main() {
  const argv = process.argv.slice(2);
  // The detached deleter's own entry point (spawnDeleter above), dispatched
  // before anything else in this function: not a session, so none of the
  // --project/heartbeat/harness-detection machinery below applies to a
  // process nobody is watching.
  if (argv[0] === "__waypost-delete") { await handleInternalDelete(argv.slice(1)); return; }
  // A stdio MCP connection is not a new harness session. Keep stdout strictly
  // protocol-only and do not touch parent membership or advisory presence.
  if (argv[0] === "team-mcp") { run("team-mcp", argv.slice(1)); return; }
  if (argv[0] === "team-mcp-config") { installMcpConfig(argv.slice(1)); return; }
  // --project is recognised ONLY in the leading position, before the command
  // name — not anywhere in argv, or a positional argument that happens to
  // equal it (a search term, say) would be swallowed as a global flag (A-8).
  let i = 0;
  while (i < argv.length) {
    if (argv[i] === "--project" && argv[i + 1] !== undefined) {
      process.env.WAYPOST_PROJECT_DIR = resolve(expandHome(argv[i + 1]));
      i += 2;
    } else break;
  }
  const args = argv.slice(i);

  // Harness first, then the session id — in that order, once, here (G-1). The
  // id carries the harness as a prefix, and deriving it before the harness was
  // known used to split one session in two: `8-48df-…` from a command that ran
  // before anything pinned WAYPOST_HARNESS, `claude-8-48df-…` from one that ran
  // after — two presence records, two trailer values, one session. Detection
  // reads the registry, which may hold project overrides, so it runs after
  // --project is known. process.ppid genuinely is the shell or harness that
  // invoked the CLI here — not inside a script bin/waypost spawns, whose parent
  // pid is bin/waypost itself and differs on every invocation. Every child this
  // process spawns inherits both via `env: { ...process.env }`.
  const [cmd = "", ...rest] = args;
  if (cmd && !["help", "--help", "-h", "version", "--version", "-v"].includes(cmd)) await migrateStateIfNeeded();
  // The harness process first (ADR-0007 amendment): the scripts this command
  // spawns beat as well, and from inside them the nearest ancestor is this very
  // process, gone the moment the command ends — and harness detection reads it
  // too, since env markers are inherited across nested harnesses while the
  // process is not. One `ps` per working command.
  if (!process.env.WAYPOST_PROC && !QUIET_COMMANDS.has(cmd)) {
    try {
      const { harnessProcess } = await import(SCRIPT_URL("presence"));
      const p = harnessProcess();
      if (p) process.env.WAYPOST_PROC = JSON.stringify(p);
    } catch { /* no process table: the counter rules stay */ }
  }
  if (!process.env.WAYPOST_HARNESS) {
    try {
      const { detectHarness } = await import(SCRIPT_URL("agents"));
      // Pinned like every read in handleSetup: this is the first registry read
      // of the process, and an unpinned one would both take its answer from a
      // foreign WAYPOST_HOME and prime the memo every later read inherits.
      const h = withRegistryHome(() => detectHarness());
      if (h && h !== "unknown") process.env.WAYPOST_HARNESS = h;
    } catch { /* detection is best-effort; a null harness is still valid */ }
  }
  // An explicit `--id` outranks an id inherited from the environment — the
  // precedence sessionId() documents, and which a pre-set WAYPOST_SESSION_ID
  // used to win against here: under a harness that exports its own id,
  // `sessions --touch --id X` wrote a record for X and beat another one for
  // the ambient session, so one command registered two live sessions.
  const idFromFlag = sessionIdFlag(process.argv);
  if (idFromFlag) process.env.WAYPOST_SESSION_ID = idFromFlag;
  else if (!process.env.WAYPOST_SESSION_ID) process.env.WAYPOST_SESSION_ID = sessionId(process.argv);
  // In a linked worktree an id that came from the environment (a wrapper's
  // constant WAYPOST_SESSION_ID, a Claude session driving two worktrees)
  // would make two live worktrees write one presence record and one lease
  // name; qualify it by the worktree, once, deterministically (ADR-0010).
  // An explicit --id means what it says.
  if (!idFromFlag && isLinkedWorktree()) {
    const tag = `-wt${worktreeTag()}`;
    if (!process.env.WAYPOST_SESSION_ID.endsWith(tag)) process.env.WAYPOST_SESSION_ID += tag;
  }
  await heartbeat(cmd);

  switch (cmd) {
    case "": handleDefault(); break;
    case "setup": await handleSetup(rest); break;
    case "next": handleNext(rest); break;
    case "bind": case "init": handleBind(rest); break;
    case "scaffold": handleScaffold(rest); break;
    case "draft": handleDraft(rest); break;
    case "story": await handleStory(rest); break;
    case "graph": {
      const forPath = opt(rest, "--for");
      if (forPath) handleGraphQuery(forPath, rest); else handleDerived("graph", rest);
      break;
    }
    case "kanban": case "codemap": handleDerived(cmd, rest); break;
    case "search": handleSearch(rest); break;
    case "reconcile": handleReconcile(rest); break;
    case "doctor": run("doctor", rest); break;
    case "diff-refs": run("diff-refs", rest); break;
    case "size": await handleSize(rest); break;
    case "clean": await handleClean(rest); break;
    case "profile": await handleProfile(rest); break;
    case "capacity": await handleCapacity(rest); break;
    case "run": await handleRun(rest); break;
    case "agents": run("agents", rest); break;
    case "harnesses": run("agents", ["harnesses", ...rest]); break;
    case "sessions": run("sessions", rest); break;
    case "team": run("team-cli", rest); break;
    case "ready": run("ready", rest); break;
    case "brief": await selfInstall(rest); run("brief", rest.filter((a) => a !== "--no-install")); break;
    case "commit": run("commit", rest); break;
    case "merge": run("commit", ["--merge", ...rest]); break;
    case "log": run("commit", ["--log", ...rest]); break;
    case "merge-derived": run("merge-derived", rest); break;
    case "lease": run("presence", leaseArgs(rest)); break;
    case "storage": run("presence", ["storage"]); break;
    case "watch": run("presence", ["watch", ...rest]); break;
    case "tokens": run("tokens", rest); break;
    case "prompt": printDoc("prompts", positionals(rest)[0]); break;
    case "skill": printDoc("skills", positionals(rest)[0], "SKILL.md"); break;
    case "skills": run("skills", rest); break;
    case "launcher": run("launcher", rest); break;
    case "status": await handleStatus(); break;
    case "version": case "--version": case "-v": process.stdout.write(`${VERSION}\n`); break;
    case "help": case "--help": case "-h": help(); break;
    default:
      process.stderr.write(`waypost: unknown command "${cmd}"\n\n`);
      help();
      process.exit(1);
  }
}

main().catch((e) => fail(e && e.message ? e.message : String(e)));
